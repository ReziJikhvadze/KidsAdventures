import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { R as Route$3, c as confirmEmail } from "./router-B8qRGRuM.mjs";
import { B as BrandLogo } from "./BrandLogo-T23ohXas.mjs";
import "../_libs/sonner.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/lucide-react.mjs";
function ConfirmEmailPage() {
  const {
    success,
    token
  } = Route$3.useSearch();
  const navigate = useNavigate();
  const [confirming, setConfirming] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  const handleConfirm = async () => {
    if (!token) return;
    setConfirming(true);
    setError(null);
    try {
      const result = await confirmEmail(token);
      if (result.success) {
        navigate({
          to: "/confirm-email",
          search: {
            success: true
          },
          replace: true
        });
      } else {
        setError(result.message);
      }
    } catch {
      setError("Could not confirm your email. Check that the API is running and try again.");
    } finally {
      setConfirming(false);
    }
  };
  const showConfirmButton = Boolean(token) && !success;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background text-foreground flex flex-col items-center justify-center px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(BrandLogo, { className: "mb-10" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md w-full rounded-3xl border border-border bg-card p-8 text-center shadow-card", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-2xl font-bold", children: success ? "Email confirmed!" : showConfirmButton ? "Confirm your email" : "Confirmation link invalid" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-muted-foreground text-sm", children: success ? "Your account is active. Sign in to start creating personalized storybooks." : showConfirmButton ? "Click the button below to activate your LittleHero Books account." : "This link may have expired. If you already clicked it once, try signing in — your email may already be confirmed." }),
      error ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-destructive text-sm", children: error }) : null,
      showConfirmButton ? /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: handleConfirm, disabled: confirming, className: "inline-flex mt-6 items-center rounded-full bg-primary text-primary-foreground px-6 py-2.5 text-sm font-semibold hover:opacity-90 transition disabled:opacity-60", children: confirming ? "Confirming…" : "Confirm my email" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "inline-flex mt-6 items-center rounded-full bg-primary text-primary-foreground px-6 py-2.5 text-sm font-semibold hover:opacity-90 transition", children: success ? "Sign in" : "Back to home" })
    ] })
  ] });
}
export {
  ConfirmEmailPage as component
};
