import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Link } from "@tanstack/react-router";
import { Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { N as Nav, F as Footer } from "./Footer-BcknXXCV.js";
import { d as Route, u as useAuth, A as ApiError } from "./router-HBU99EUm.js";
import { a as confirmCheckoutSession } from "./subscriptions-BIwZDbf6.js";
import "./BrandLogo-T23ohXas.js";
import "@radix-ui/react-dialog";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-label";
import "@tanstack/react-query";
function BillingSuccess() {
  const {
    session_id: sessionId
  } = Route.useSearch();
  const {
    refreshAccountBalance,
    user
  } = useAuth();
  const [confirming, setConfirming] = useState(!!sessionId);
  const [credits, setCredits] = useState(null);
  useEffect(() => {
    if (!sessionId) {
      void refreshAccountBalance();
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const balance = await confirmCheckoutSession(sessionId);
        if (cancelled) return;
        setCredits(balance.bookCredits);
        await refreshAccountBalance();
      } catch (err) {
        if (cancelled) return;
        const message = err instanceof ApiError ? err.message : "Could not confirm payment. Try refreshing.";
        toast.error(message);
        await refreshAccountBalance();
      } finally {
        if (!cancelled) setConfirming(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [sessionId, refreshAccountBalance]);
  const displayCredits = credits ?? user?.bookCredits ?? 0;
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-background text-foreground", children: [
    /* @__PURE__ */ jsx(Nav, {}),
    /* @__PURE__ */ jsxs("main", { className: "mx-auto max-w-lg px-6 py-24 text-center", children: [
      confirming ? /* @__PURE__ */ jsx(Loader2, { className: "h-14 w-14 mx-auto text-primary mb-6 animate-spin" }) : /* @__PURE__ */ jsx(CheckCircle2, { className: "h-14 w-14 mx-auto text-primary mb-6" }),
      /* @__PURE__ */ jsx("h1", { className: "font-display text-3xl font-bold", children: confirming ? "Confirming payment…" : "Payment successful" }),
      /* @__PURE__ */ jsx("p", { className: "mt-4 text-muted-foreground", children: confirming ? "Adding your book credits now." : `Your book credits have been added — you now have ${displayCredits} credit${displayCredits === 1 ? "" : "s"}. Open My Books and tap Create illustrated PDF on any story.` }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 flex flex-col sm:flex-row gap-3 justify-center", children: [
        /* @__PURE__ */ jsx(Link, { to: "/my-packs", className: "inline-flex items-center justify-center rounded-full bg-primary text-primary-foreground px-6 py-3 font-semibold hover:opacity-90 transition", children: "My books" }),
        /* @__PURE__ */ jsx(Link, { to: "/", hash: "pricing", className: "inline-flex items-center justify-center rounded-full border border-border px-6 py-3 font-semibold hover:bg-secondary transition", children: "View pricing" })
      ] })
    ] }),
    /* @__PURE__ */ jsx(Footer, {})
  ] });
}
export {
  BillingSuccess as component
};
