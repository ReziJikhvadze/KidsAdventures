import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { B as BrandLogo } from "./BrandLogo-T23ohXas.mjs";
import { u as useAuth, A as ApiError } from "./router-B8qRGRuM.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { R as Root, P as Portal, C as Content, a as Close, T as Title, D as Description, O as Overlay } from "../_libs/radix-ui__react-dialog.mjs";
import { c as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { S as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { R as Root$1 } from "../_libs/radix-ui__react-label.mjs";
import { L as Library, S as Sparkles, K as User, N as LogOut, b as LoaderCircle, X } from "../_libs/lucide-react.mjs";
function formatNavQuotaLabel({
  bookCredits,
  storiesRemainingThisMonth,
  isLoading
}) {
  if (isLoading) return "…";
  if (storiesRemainingThisMonth > 0) {
    return storiesRemainingThisMonth === 1 ? "1 story left" : `${storiesRemainingThisMonth} stories left`;
  }
  if (bookCredits > 0) {
    return `${bookCredits} credit${bookCredits === 1 ? "" : "s"} · limit reached`;
  }
  return "Buy credits for more";
}
function formatNavQuotaTitle({
  bookCredits,
  storiesRemainingThisMonth,
  storiesAllowedThisMonth
}) {
  const allowed = storiesAllowedThisMonth ?? 1 + bookCredits;
  if (storiesRemainingThisMonth > 0 && bookCredits > 0) {
    return `${storiesRemainingThisMonth} of ${allowed} stories this month — 1 free every month plus ${bookCredits} purchased credit${bookCredits === 1 ? "" : "s"}.`;
  }
  if (storiesRemainingThisMonth > 0) {
    return `${storiesRemainingThisMonth} of ${allowed} free stories this month.`;
  }
  if (bookCredits > 0) {
    return `Monthly story limit used. You still have ${bookCredits} credit${bookCredits === 1 ? "" : "s"} for next month (plus 1 free).`;
  }
  return "Buy book credits to create more illustrated stories.";
}
function formatCreditsBadgeLabel({
  bookCredits,
  storiesRemainingThisMonth
}) {
  if (bookCredits > 0) {
    return `${bookCredits} story credit${bookCredits === 1 ? "" : "s"}`;
  }
  if (storiesRemainingThisMonth > 0) {
    return storiesRemainingThisMonth === 1 ? "1 free story" : `${storiesRemainingThisMonth} free stories`;
  }
  return "0 story credits";
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const Dialog = Root;
const DialogPortal = Portal;
const DialogOverlay = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Overlay,
  {
    ref,
    className: cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props
  }
));
DialogOverlay.displayName = Overlay.displayName;
const DialogContent = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogPortal, { children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx(DialogOverlay, {}),
  /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Content,
    {
      ref,
      className: cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Close, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Close" })
        ] })
      ]
    }
  )
] }));
DialogContent.displayName = Content.displayName;
const DialogHeader = ({ className, ...props }) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props });
DialogHeader.displayName = "DialogHeader";
const DialogTitle = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Title,
  {
    ref,
    className: cn("text-lg font-semibold leading-none tracking-tight", className),
    ...props
  }
));
DialogTitle.displayName = Title.displayName;
const DialogDescription = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Description,
  {
    ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props
  }
));
DialogDescription.displayName = Description.displayName;
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = reactExports.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";
const Input = reactExports.forwardRef(
  ({ className, type, ...props }, ref) => {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type,
        className: cn(
          "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Input.displayName = "Input";
const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
);
const Label = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(Root$1, { ref, className: cn(labelVariants(), className), ...props }));
Label.displayName = Root$1.displayName;
function AuthDialog({
  open,
  onOpenChange,
  onSuccess,
  defaultMode = "login"
}) {
  const { login, register } = useAuth();
  const [mode, setMode] = reactExports.useState(defaultMode);
  const [email, setEmail] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [busy, setBusy] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (open) setMode(defaultMode);
  }, [open, defaultMode]);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "login") {
        await login(email.trim(), password);
        toast.success("Welcome back!");
        onOpenChange(false);
        onSuccess?.();
      } else {
        const message = await register(email.trim(), password);
        toast.success(message);
        setMode("login");
      }
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Something went wrong. Try again.";
      toast.error(message);
    } finally {
      setBusy(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open, onOpenChange, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-md", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { className: "font-display", children: mode === "login" ? "Sign in" : "Create your account" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: mode === "login" ? "Sign in to create personalized storybooks for your child." : "Free plan includes 1 full illustrated story per month. Buy book credits for more. We will email you a confirmation link." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "auth-email", children: "Email" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Input,
          {
            id: "auth-email",
            type: "email",
            autoComplete: "email",
            required: true,
            value: email,
            onChange: (e) => setEmail(e.target.value)
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "auth-password", children: "Password" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Input,
          {
            id: "auth-password",
            type: "password",
            autoComplete: mode === "login" ? "current-password" : "new-password",
            required: true,
            minLength: 8,
            value: password,
            onChange: (e) => setPassword(e.target.value)
          }
        ),
        mode === "register" && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "At least 8 characters with upper, lower, and a number." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "submit", className: "w-full", disabled: busy, children: [
        busy && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
        mode === "login" ? "Sign in" : "Create account"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-sm text-muted-foreground", children: mode === "login" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "New here?",
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          className: "text-primary font-semibold hover:underline",
          onClick: () => setMode("register"),
          children: "Create an account"
        }
      )
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Already have an account?",
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          className: "text-primary font-semibold hover:underline",
          onClick: () => setMode("login"),
          children: "Sign in"
        }
      )
    ] }) })
  ] }) });
}
function Nav() {
  const { user, isAuthenticated, isLoading, logout } = useAuth();
  const [authOpen, setAuthOpen] = reactExports.useState(false);
  const anchorLinks = [
    { label: "How it works", href: "/#how" },
    { label: "Themes", href: "/#themes" },
    { label: "Pricing", href: "/#pricing" },
    { label: "FAQ", href: "/#faq" }
  ];
  const creditLabel = formatNavQuotaLabel({
    bookCredits: user?.bookCredits ?? 0,
    storiesRemainingThisMonth: user?.storiesRemainingThisMonth ?? 0,
    isLoading
  });
  const creditTitle = formatNavQuotaTitle({
    bookCredits: user?.bookCredits ?? 0,
    storiesRemainingThisMonth: user?.storiesRemainingThisMonth ?? 0,
    storiesAllowedThisMonth: user?.storiesAllowedThisMonth
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/60", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-4 sm:px-6 min-h-16 py-2 flex flex-wrap items-center justify-between gap-x-3 gap-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(BrandLogo, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "hidden md:flex items-center gap-8 text-sm text-muted-foreground order-3 md:order-none w-full md:w-auto justify-center md:justify-start", children: anchorLinks.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: l.href, className: "hover:text-foreground transition-colors", children: l.label }, l.href)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0 ml-auto", children: [
        isAuthenticated && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: "/my-packs",
            className: "group inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/8 pl-2 pr-3 py-1.5 text-sm font-semibold text-primary shadow-sm hover:bg-primary/12 hover:border-primary/35 transition",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "grid place-items-center h-8 w-8 rounded-full bg-primary/15 ring-1 ring-primary/20 group-hover:bg-primary/20 transition", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Library, { className: "h-4 w-4" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex flex-col items-start leading-tight min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "My Books" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "span",
                  {
                    className: "inline-flex items-center gap-1 text-[10px] font-bold text-amber-800",
                    title: creditTitle,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-3 w-3 shrink-0" }),
                      creditLabel
                    ]
                  }
                )
              ] })
            ]
          }
        ),
        isAuthenticated && user ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "hidden xl:inline-flex items-center gap-1.5 text-xs text-muted-foreground max-w-[140px] truncate", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-3.5 w-3.5 shrink-0" }),
            user.email
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: logout,
              className: "inline-flex items-center gap-1 rounded-full border border-border px-3 py-2 text-sm font-medium hover:bg-secondary transition",
              title: "Sign out",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hidden sm:inline", children: "Sign out" })
              ]
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setAuthOpen(true),
            className: "inline-flex items-center rounded-full border border-border px-4 py-2 text-sm font-semibold hover:bg-secondary transition",
            children: "Sign in"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: "/#generator",
            className: "inline-flex items-center rounded-full bg-primary text-primary-foreground px-4 py-2 text-sm font-semibold hover:opacity-90 transition",
            children: "Create book"
          }
        )
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AuthDialog, { open: authOpen, onOpenChange: setAuthOpen, defaultMode: "login" })
  ] });
}
function Footer() {
  const cols = [
    { title: "Product", links: ["Themes", "Pricing", "Examples", "What's new"] },
    { title: "Company", links: ["About", "Blog", "Press", "Contact"] },
    { title: "Support", links: ["Help center", "Printing tips", "Privacy", "Terms"] }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "border-t border-border bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-6 py-16 grid md:grid-cols-[1.5fr_1fr_1fr_1fr] gap-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(BrandLogo, { asLink: false }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm text-muted-foreground max-w-sm", children: "Personalized printable adventure books for kids ages 4–12. Made with care by parents, for parents." })
      ] }),
      cols.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold", children: c.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-4 space-y-2 text-sm text-muted-foreground", children: c.links.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "#", className: "hover:text-foreground transition", children: l }) }, l)) })
      ] }, c.title))
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-6 py-6 flex flex-col sm:flex-row gap-3 justify-between items-center text-xs text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        "© ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " LittleHero Books. All rights reserved."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "Made with love for curious kids." })
    ] }) })
  ] });
}
export {
  AuthDialog as A,
  Button as B,
  Footer as F,
  Nav as N,
  cn as c,
  formatCreditsBadgeLabel as f
};
