import { a as apiRequest } from "./router-HBU99EUm.js";
async function createCheckoutSession(planType) {
  return apiRequest("/api/subscriptions/create-checkout-session", {
    method: "POST",
    body: JSON.stringify({ planType })
  });
}
async function confirmCheckoutSession(sessionId) {
  return apiRequest("/api/subscriptions/confirm-checkout", {
    method: "POST",
    body: JSON.stringify({ sessionId })
  });
}
export {
  confirmCheckoutSession as a,
  createCheckoutSession as c
};
