import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { createRootRouteWithContext, useRouter, Link, Outlet, HeadContent, Scripts, createFileRoute, lazyRouteComponent, createRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useCallback, useEffect, useMemo, createContext, useContext } from "react";
import { Toaster as Toaster$1 } from "sonner";
const appCss = "/assets/styles-CvYU5-hT.css";
function reportLovableError(error, context = {}) {
  if (typeof window === "undefined") return;
  window.__lovableEvents?.captureException?.(
    error,
    {
      source: "react_error_boundary",
      route: window.location.pathname,
      ...context
    },
    {
      mechanism: "react_error_boundary",
      handled: false,
      severity: "error"
    }
  );
}
const Toaster = ({ ...props }) => {
  return /* @__PURE__ */ jsx(
    Toaster$1,
    {
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
        }
      },
      ...props
    }
  );
};
const TOKEN_KEY = "adventurepacks_token";
let unauthorizedHandler = null;
function setUnauthorizedHandler(handler) {
  unauthorizedHandler = handler;
}
function getApiBaseUrl() {
  const base = "http://localhost:5000";
  return base.replace(/\/$/, "");
}
function getToken() {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(TOKEN_KEY);
}
function setToken(token) {
  if (typeof window === "undefined") return;
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}
class ApiError extends Error {
  status;
  constructor(message, status) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}
async function apiRequest(path, options = {}) {
  const { auth = true, ...fetchOptions } = options;
  const headers = new Headers(fetchOptions.headers);
  if (auth) {
    const token = getToken();
    if (token) headers.set("Authorization", `Bearer ${token}`);
  }
  if (fetchOptions.body && !(fetchOptions.body instanceof FormData)) {
    if (!headers.has("Content-Type")) {
      headers.set("Content-Type", "application/json");
    }
  }
  const response = await fetch(`${getApiBaseUrl()}${path}`, {
    ...fetchOptions,
    headers
  });
  if (!response.ok) {
    let message = response.statusText;
    try {
      const body = await response.json();
      if (body.message) message = body.message;
    } catch {
    }
    if (response.status === 401 && auth) {
      unauthorizedHandler?.();
      throw new ApiError(
        message && message !== "Unauthorized" ? message : "Your session expired. Please sign in again.",
        response.status
      );
    }
    throw new ApiError(message, response.status);
  }
  if (response.status === 204) {
    return void 0;
  }
  const text = await response.text();
  if (!text) return void 0;
  return JSON.parse(text);
}
async function getSession() {
  return apiRequest("/api/auth/me");
}
async function register(email, password) {
  return apiRequest("/api/auth/register", {
    method: "POST",
    body: JSON.stringify({ email, password })
  });
}
async function login(email, password) {
  const result = await apiRequest("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password })
  });
  setToken(result.token);
  return result;
}
function logout() {
  setToken(null);
}
async function confirmEmail(token) {
  return apiRequest("/api/auth/confirm-email", {
    method: "POST",
    auth: false,
    body: JSON.stringify({ token })
  });
}
const USER_KEY = "adventurepacks_user";
const AuthContext = createContext(null);
function normalizeUser(raw) {
  const subscriptionType = raw.subscriptionType ?? "Free";
  const bookCredits = typeof raw.bookCredits === "number" ? raw.bookCredits : 0;
  const storiesAllowedThisMonth = typeof raw.storiesAllowedThisMonth === "number" ? raw.storiesAllowedThisMonth : 1 + bookCredits;
  const storiesUsedThisMonth = typeof raw.storiesUsedThisMonth === "number" ? raw.storiesUsedThisMonth : 0;
  const storiesRemainingThisMonth = typeof raw.storiesRemainingThisMonth === "number" ? raw.storiesRemainingThisMonth : Math.max(0, storiesAllowedThisMonth - storiesUsedThisMonth);
  const welcomeStoryRemaining = typeof raw.welcomeStoryRemaining === "number" ? raw.welcomeStoryRemaining : 0;
  return {
    email: raw.email,
    subscriptionType,
    bookCredits,
    storiesUsedThisMonth,
    storiesAllowedThisMonth,
    storiesRemainingThisMonth,
    welcomeStoryRemaining,
    hasUnlimitedPdf: false
  };
}
function userFromSessionInfo(session) {
  return normalizeUser({
    email: session.email,
    subscriptionType: session.subscriptionType,
    bookCredits: session.bookCredits ?? 0,
    storiesUsedThisMonth: session.storiesUsedThisMonth,
    storiesAllowedThisMonth: session.storiesAllowedThisMonth,
    storiesRemainingThisMonth: session.storiesRemainingThisMonth,
    welcomeStoryRemaining: session.welcomeStoryRemaining ?? 0
  });
}
function loadStoredUser() {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (!parsed.email) return null;
    return normalizeUser({ ...parsed, email: parsed.email });
  } catch {
    return null;
  }
}
function persistUser(user) {
  if (typeof window === "undefined") return;
  if (user) localStorage.setItem(USER_KEY, JSON.stringify(user));
  else localStorage.removeItem(USER_KEY);
}
function userFromAuthResponse(session) {
  return normalizeUser({
    email: session.email,
    subscriptionType: session.subscriptionType,
    bookCredits: session.bookCredits ?? 0,
    storiesUsedThisMonth: session.storiesUsedThisMonth,
    storiesAllowedThisMonth: session.storiesAllowedThisMonth,
    storiesRemainingThisMonth: session.storiesRemainingThisMonth,
    welcomeStoryRemaining: session.welcomeStoryRemaining ?? 0
  });
}
function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const logout$1 = useCallback(() => {
    logout();
    setUser(null);
    persistUser(null);
  }, []);
  const applySessionInfo = useCallback((session) => {
    const next = userFromSessionInfo(session);
    setUser(next);
    persistUser(next);
  }, []);
  const refreshAccountBalance = useCallback(async () => {
    const token = getToken();
    if (!token) {
      logout$1();
      return;
    }
    try {
      const session = await getSession();
      applySessionInfo(session);
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        logout$1();
        return;
      }
      console.warn("Could not refresh account session", error);
    }
  }, [applySessionInfo, logout$1]);
  useEffect(() => {
    setUnauthorizedHandler(logout$1);
    return () => setUnauthorizedHandler(null);
  }, [logout$1]);
  useEffect(() => {
    const token = getToken();
    if (!token) {
      setUser(null);
      persistUser(null);
      setIsLoading(false);
      return;
    }
    const stored = loadStoredUser();
    if (stored) setUser(stored);
    void refreshAccountBalance().finally(() => setIsLoading(false));
  }, [refreshAccountBalance]);
  const applySession = useCallback(
    (session) => {
      const next = userFromAuthResponse(session);
      setUser(next);
      persistUser(next);
      void refreshAccountBalance();
    },
    [refreshAccountBalance]
  );
  const setBookCredits = useCallback((credits) => {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, bookCredits: credits };
      persistUser(next);
      return next;
    });
  }, []);
  const login$1 = useCallback(
    async (email, password) => {
      const session = await login(email, password);
      applySession(session);
    },
    [applySession]
  );
  const register$1 = useCallback(async (email, password) => {
    const result = await register(email, password);
    return result.message;
  }, []);
  const canCreatePdf = !!user && !!getToken();
  const value = useMemo(
    () => ({
      user,
      isAuthenticated: !isLoading && !!user && !!getToken(),
      isLoading,
      canCreatePdf,
      login: login$1,
      register: register$1,
      logout: logout$1,
      applySession,
      refreshAccountBalance,
      setBookCredits
    }),
    [user, isLoading, canCreatePdf, login$1, register$1, logout$1, applySession, refreshAccountBalance, setBookCredits]
  );
  return /* @__PURE__ */ jsx(AuthContext.Provider, { value, children });
}
function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
function NotFoundComponent() {
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$5 = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "LittleHero Books" },
      { name: "description", content: "Personalized storybooks for kids" },
      { property: "og:title", content: "LittleHero Books" },
      { property: "og:description", content: "Personalized storybooks for kids" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Lovable" }
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700;9..144,800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
      },
      {
        rel: "stylesheet",
        href: appCss
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsx("head", { children: /* @__PURE__ */ jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$5.useRouteContext();
  return /* @__PURE__ */ jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxs(AuthProvider, { children: [
    /* @__PURE__ */ jsx(Outlet, {}),
    /* @__PURE__ */ jsx(Toaster, {})
  ] }) });
}
const $$splitComponentImporter$4 = () => import("./my-packs-CFkleVLN.js");
const Route$4 = createFileRoute("/my-packs")({
  head: () => ({
    meta: [{
      title: "My books — LittleHero Books"
    }, {
      name: "description",
      content: "Read your stories and download illustrated storybook PDFs."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./confirm-email-CbHS61dE.js");
const Route$3 = createFileRoute("/confirm-email")({
  validateSearch: (search) => ({
    success: search.success === "1" || search.success === 1 || search.success === true,
    token: typeof search.token === "string" ? search.token : void 0
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./index-CcUHCtDN.js");
const Route$2 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "LittleHero Books — Personalized storybooks for kids"
    }, {
      name: "description",
      content: "Create personalized illustrated storybooks starring your child. Story in minutes, PDF when you are ready."
    }, {
      property: "og:title",
      content: "LittleHero Books — Personalized storybooks for kids"
    }, {
      property: "og:description",
      content: "Personalized stories and optional illustrated PDFs for children ages 3–12."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./success-CreUDPMm.js");
const Route$1 = createFileRoute("/billing/success")({
  validateSearch: (search) => ({
    session_id: typeof search.session_id === "string" ? search.session_id : void 0
  }),
  head: () => ({
    meta: [{
      title: "Payment successful — LittleHero Books"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./cancel-CEvFMEXs.js");
const Route = createFileRoute("/billing/cancel")({
  head: () => ({
    meta: [{
      title: "Checkout cancelled — LittleHero Books"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const MyPacksRoute = Route$4.update({
  id: "/my-packs",
  path: "/my-packs",
  getParentRoute: () => Route$5
});
const ConfirmEmailRoute = Route$3.update({
  id: "/confirm-email",
  path: "/confirm-email",
  getParentRoute: () => Route$5
});
const IndexRoute = Route$2.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$5
});
const BillingSuccessRoute = Route$1.update({
  id: "/billing/success",
  path: "/billing/success",
  getParentRoute: () => Route$5
});
const BillingCancelRoute = Route.update({
  id: "/billing/cancel",
  path: "/billing/cancel",
  getParentRoute: () => Route$5
});
const rootRouteChildren = {
  IndexRoute,
  ConfirmEmailRoute,
  MyPacksRoute,
  BillingCancelRoute,
  BillingSuccessRoute
};
const routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  ApiError as A,
  Route$3 as R,
  apiRequest as a,
  getApiBaseUrl as b,
  confirmEmail as c,
  Route$1 as d,
  getToken as g,
  router as r,
  useAuth as u
};
