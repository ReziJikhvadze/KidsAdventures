import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { BookOpen } from "lucide-react";
import { Link } from "@tanstack/react-router";
function BrandLogo({ className = "", asLink = true }) {
  const content = /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("span", { className: "inline-flex items-center justify-center h-8 w-8 rounded-xl bg-primary text-primary-foreground shrink-0", children: /* @__PURE__ */ jsx(BookOpen, { className: "h-4 w-4" }) }),
    /* @__PURE__ */ jsx("span", { className: "font-display text-lg font-bold tracking-tight", children: "LittleHero Books" })
  ] });
  if (!asLink) {
    return /* @__PURE__ */ jsx("div", { className: `flex items-center gap-2 ${className}`, children: content });
  }
  return /* @__PURE__ */ jsx(Link, { to: "/", className: `flex items-center gap-2 ${className}`, children: content });
}
export {
  BrandLogo as B
};
