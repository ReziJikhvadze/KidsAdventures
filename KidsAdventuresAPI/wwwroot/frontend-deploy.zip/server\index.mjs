globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { H as HTTPError, d as defineHandler, t as toEventHandler, a as defineLazyEventHandler, b as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/assets/confirm-email-tX1yvT5_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"710-T1V4q3RkoDcAfcvobn4T9+3wYzU"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 1808,
    "path": "../public/assets/confirm-email-tX1yvT5_.js"
  },
  "/assets/BrandLogo-DBwC8tOB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7a2-VOtBGfVfv3cCOFTZmJRpDhKoUCo"',
    "mtime": "2026-06-07T12:11:51.518Z",
    "size": 1954,
    "path": "../public/assets/BrandLogo-DBwC8tOB.js"
  },
  "/assets/Footer-ByBmKDJd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1297c-tMpPi0XICnrjjEUcbGEyCKWb3HA"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 76156,
    "path": "../public/assets/Footer-ByBmKDJd.js"
  },
  "/assets/hero-QPgGu4Uy.jpg": {
    "type": "image/jpeg",
    "etag": '"219c9-vRYBV8lRDUMQ/fC529OcmTuGqKs"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 137673,
    "path": "../public/assets/hero-QPgGu4Uy.jpg"
  },
  "/assets/index-BoioA_ui.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"da95-Eigjw9XpLavJwxJZcArb9ogJq0E"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 55957,
    "path": "../public/assets/index-BoioA_ui.js"
  },
  "/assets/cancel-D2NLbsAC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"46a-OZM0+mDbjq5bIEe10bHZbR2MDK8"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 1130,
    "path": "../public/assets/cancel-D2NLbsAC.js"
  },
  "/assets/my-packs-CcWOf--V.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"874f-tgXqToJ75ebS2JchzEds4D01iqM"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 34639,
    "path": "../public/assets/my-packs-CcWOf--V.js"
  },
  "/assets/StoryBookReader-C2CWuNhE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"9180-wrGQso/9H9QqZyrmzydQAZWFW/c"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 37248,
    "path": "../public/assets/StoryBookReader-C2CWuNhE.js"
  },
  "/assets/styles-CvYU5-hT.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"17898-Bgn0lVhNsQGovze9c9wcj22YsUk"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 96408,
    "path": "../public/assets/styles-CvYU5-hT.css"
  },
  "/assets/theme-animals-Dua5i12h.jpg": {
    "type": "image/jpeg",
    "etag": '"7df1-ylvKkIdHhq4VF5gfAoxQdy1LHQ4"',
    "mtime": "2026-06-07T12:11:51.514Z",
    "size": 32241,
    "path": "../public/assets/theme-animals-Dua5i12h.jpg"
  },
  "/assets/success-Cgivciqi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7bb-o5ch+fO+shmR7/tMbRpzGKNQk98"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 1979,
    "path": "../public/assets/success-Cgivciqi.js"
  },
  "/assets/theme-airplanes-BRcmx3yh.jpg": {
    "type": "image/jpeg",
    "etag": '"6daf-j4aaePW9Y3WyPG6KPwEK1ItiYNY"',
    "mtime": "2026-06-07T12:11:51.514Z",
    "size": 28079,
    "path": "../public/assets/theme-airplanes-BRcmx3yh.jpg"
  },
  "/assets/theme-dinosaurs-Jy-PzUiV.jpg": {
    "type": "image/jpeg",
    "etag": '"a9ce-oJAwkdggFhr50tjJ077IyntgZpA"',
    "mtime": "2026-06-07T12:11:51.514Z",
    "size": 43470,
    "path": "../public/assets/theme-dinosaurs-Jy-PzUiV.jpg"
  },
  "/assets/theme-pirates-ruqjfyS9.jpg": {
    "type": "image/jpeg",
    "etag": '"a67e-abhKg7M5LqrCh+Bpl3yiVeMKtck"',
    "mtime": "2026-06-07T12:11:51.514Z",
    "size": 42622,
    "path": "../public/assets/theme-pirates-ruqjfyS9.jpg"
  },
  "/assets/subscriptions-CKna-p17.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"133-Wu1F5b/2KR6KDuWjf6CcPTGiots"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 307,
    "path": "../public/assets/subscriptions-CKna-p17.js"
  },
  "/server/server.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d0d-s+evJPbccCvIiHoRqcZIlu7nnzE"',
    "mtime": "2026-06-06T20:01:16.549Z",
    "size": 3341,
    "path": "../public/server/server.js"
  },
  "/assets/theme-space-XCcLprgr.jpg": {
    "type": "image/jpeg",
    "etag": '"757a-1D+PO7+BDoY7RbL1AfRJr0PRyiM"',
    "mtime": "2026-06-07T12:11:51.514Z",
    "size": 30074,
    "path": "../public/assets/theme-space-XCcLprgr.jpg"
  },
  "/assets/index-Dh35LJtr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f2f6-S/6WDeya685fAkVkEdBv8irgxMI"',
    "mtime": "2026-06-07T12:11:51.516Z",
    "size": 389878,
    "path": "../public/assets/index-Dh35LJtr.js"
  },
  "/client/assets/BrandLogo-BxJkXt5m.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7a2-RGt8u4/WYc+DXLTQiM3dzhdVPaU"',
    "mtime": "2026-06-06T20:01:16.038Z",
    "size": 1954,
    "path": "../public/client/assets/BrandLogo-BxJkXt5m.js"
  },
  "/client/assets/confirm-email-CNoRb66h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"710-3owPWjyuMCjY9rcRe57QHwfdJoM"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 1808,
    "path": "../public/client/assets/confirm-email-CNoRb66h.js"
  },
  "/client/assets/Footer-D_kUYzYh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1297c-/9+h2Ivu34bBuPPNhx7N29jaJBE"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 76156,
    "path": "../public/client/assets/Footer-D_kUYzYh.js"
  },
  "/client/assets/cancel-BVeuJxX9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"46a-Z9QEqdMiNzXHRg4HRAVoKKJYUzA"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 1130,
    "path": "../public/client/assets/cancel-BVeuJxX9.js"
  },
  "/client/assets/hero-QPgGu4Uy.jpg": {
    "type": "image/jpeg",
    "etag": '"219c9-vRYBV8lRDUMQ/fC529OcmTuGqKs"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 137673,
    "path": "../public/client/assets/hero-QPgGu4Uy.jpg"
  },
  "/client/assets/my-packs-DkqmCl3K.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"874f-Rjuj+BcsdGAB+cBQsrgqVZ60S14"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 34639,
    "path": "../public/client/assets/my-packs-DkqmCl3K.js"
  },
  "/client/assets/index-h7v8_fqt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"da95-lrLx1lousgxIzxzHuIu/w2YSNbs"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 55957,
    "path": "../public/client/assets/index-h7v8_fqt.js"
  },
  "/client/assets/subscriptions-CqzzUC1V.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"133-nekPbEU89L7di/YEPGHiDEp2faE"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 307,
    "path": "../public/client/assets/subscriptions-CqzzUC1V.js"
  },
  "/client/assets/StoryBookReader-CzSdR0TM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"9180-yfU9dqV1SOWz0zhXcjCj/T8kOjA"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 37248,
    "path": "../public/client/assets/StoryBookReader-CzSdR0TM.js"
  },
  "/client/assets/success-jYUoQdCa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7bb-w/P7HY+rMAceKxDfwB0AHOCF+H8"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 1979,
    "path": "../public/client/assets/success-jYUoQdCa.js"
  },
  "/client/assets/theme-airplanes-BRcmx3yh.jpg": {
    "type": "image/jpeg",
    "etag": '"6daf-j4aaePW9Y3WyPG6KPwEK1ItiYNY"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 28079,
    "path": "../public/client/assets/theme-airplanes-BRcmx3yh.jpg"
  },
  "/client/assets/theme-animals-Dua5i12h.jpg": {
    "type": "image/jpeg",
    "etag": '"7df1-ylvKkIdHhq4VF5gfAoxQdy1LHQ4"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 32241,
    "path": "../public/client/assets/theme-animals-Dua5i12h.jpg"
  },
  "/client/assets/index-Bzq_Mv8S.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5f2c2-QXPLyXYEWxpNunNWGbOaDvw2TkA"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 389826,
    "path": "../public/client/assets/index-Bzq_Mv8S.js"
  },
  "/client/assets/styles-CvYU5-hT.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"17898-Bgn0lVhNsQGovze9c9wcj22YsUk"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 96408,
    "path": "../public/client/assets/styles-CvYU5-hT.css"
  },
  "/client/assets/theme-pirates-ruqjfyS9.jpg": {
    "type": "image/jpeg",
    "etag": '"a67e-abhKg7M5LqrCh+Bpl3yiVeMKtck"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 42622,
    "path": "../public/client/assets/theme-pirates-ruqjfyS9.jpg"
  },
  "/client/assets/theme-space-XCcLprgr.jpg": {
    "type": "image/jpeg",
    "etag": '"757a-1D+PO7+BDoY7RbL1AfRJr0PRyiM"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 30074,
    "path": "../public/client/assets/theme-space-XCcLprgr.jpg"
  },
  "/server/assets/BrandLogo-T23ohXas.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"387-YratFTZ6ymYP+g/gf/VCfQNnz9Q"',
    "mtime": "2026-06-06T20:01:16.552Z",
    "size": 903,
    "path": "../public/server/assets/BrandLogo-T23ohXas.js"
  },
  "/client/assets/theme-dinosaurs-Jy-PzUiV.jpg": {
    "type": "image/jpeg",
    "etag": '"a9ce-oJAwkdggFhr50tjJ077IyntgZpA"',
    "mtime": "2026-06-06T20:01:16.035Z",
    "size": 43470,
    "path": "../public/client/assets/theme-dinosaurs-Jy-PzUiV.jpg"
  },
  "/server/assets/cancel-CEvFMEXs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6f3-KiX0X/+OjDsp47ibyQVvrvpLMcw"',
    "mtime": "2026-06-06T20:01:16.550Z",
    "size": 1779,
    "path": "../public/server/assets/cancel-CEvFMEXs.js"
  },
  "/server/assets/confirm-email-CbHS61dE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b55-KB/0ksT65sJtY3xbuZiDmL20yBI"',
    "mtime": "2026-06-06T20:01:16.550Z",
    "size": 2901,
    "path": "../public/server/assets/confirm-email-CbHS61dE.js"
  },
  "/demo/demo-page-1.png": {
    "type": "image/png",
    "etag": '"215cb3-CATBZFws/2rKAvmpGi7UnW1qtcM"',
    "mtime": "2026-06-05T14:27:53.078Z",
    "size": 2186419,
    "path": "../public/demo/demo-page-1.png"
  },
  "/demo/demo-page-3.png": {
    "type": "image/png",
    "etag": '"2102a4-NflbS9mVpPZXx0zue6ezJygUxVA"',
    "mtime": "2026-06-05T14:29:19.486Z",
    "size": 2163364,
    "path": "../public/demo/demo-page-3.png"
  },
  "/client/demo/demo-page-1.png": {
    "type": "image/png",
    "etag": '"215cb3-CATBZFws/2rKAvmpGi7UnW1qtcM"',
    "mtime": "2026-06-05T14:27:53.078Z",
    "size": 2186419,
    "path": "../public/client/demo/demo-page-1.png"
  },
  "/demo/demo-page-2.png": {
    "type": "image/png",
    "etag": '"23d2fe-p6xL954qGJIllVjDI44iF9liNZs"',
    "mtime": "2026-06-05T14:28:17.064Z",
    "size": 2347774,
    "path": "../public/demo/demo-page-2.png"
  },
  "/client/demo/demo-page-2.png": {
    "type": "image/png",
    "etag": '"23d2fe-p6xL954qGJIllVjDI44iF9liNZs"',
    "mtime": "2026-06-05T14:28:17.064Z",
    "size": 2347774,
    "path": "../public/client/demo/demo-page-2.png"
  },
  "/client/demo/demo-page-3.png": {
    "type": "image/png",
    "etag": '"2102a4-NflbS9mVpPZXx0zue6ezJygUxVA"',
    "mtime": "2026-06-05T14:29:19.486Z",
    "size": 2163364,
    "path": "../public/client/demo/demo-page-3.png"
  },
  "/server/assets/empty-plugin-adapters-BFgPZ6_d.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"84-DWfR3SDM2zV6BmnQXtA8G39T+7w"',
    "mtime": "2026-06-06T20:01:16.549Z",
    "size": 132,
    "path": "../public/server/assets/empty-plugin-adapters-BFgPZ6_d.js"
  },
  "/server/assets/Footer-BcknXXCV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"45b3-6QSXMSxYGm2WOXVQtdGWCnyeWR4"',
    "mtime": "2026-06-06T20:01:16.552Z",
    "size": 17843,
    "path": "../public/server/assets/Footer-BcknXXCV.js"
  },
  "/server/assets/server-ObyzIYKQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"e404-l2pNV1h8VK0TzQEYKMhJJ2Hxt80"',
    "mtime": "2026-06-06T20:01:16.549Z",
    "size": 58372,
    "path": "../public/server/assets/server-ObyzIYKQ.js"
  },
  "/server/assets/index-CcUHCtDN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"fcae-pJeShzwhnd3sHZ0IDp7xgz4PyJc"',
    "mtime": "2026-06-06T20:01:16.550Z",
    "size": 64686,
    "path": "../public/server/assets/index-CcUHCtDN.js"
  },
  "/server/assets/my-packs-CFkleVLN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"66a5-HrGiDA6sZ857LhIDsuWWNzaUzxA"',
    "mtime": "2026-06-06T20:01:16.550Z",
    "size": 26277,
    "path": "../public/server/assets/my-packs-CFkleVLN.js"
  },
  "/server/assets/start-BbvJLkFM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6b2-LaxhqnCgO+wuoxuyYo9bDf+w5tY"',
    "mtime": "2026-06-06T20:01:16.549Z",
    "size": 1714,
    "path": "../public/server/assets/start-BbvJLkFM.js"
  },
  "/server/assets/router-HBU99EUm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4291-GBYhOaaxopQkbCwwWh3SED7MZkg"',
    "mtime": "2026-06-06T20:01:16.549Z",
    "size": 17041,
    "path": "../public/server/assets/router-HBU99EUm.js"
  },
  "/server/assets/StoryBookReader-DcQ0f9R1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"78ef-mu4il/DjP5vVNhCVLS7PW20JYUY"',
    "mtime": "2026-06-06T20:01:16.550Z",
    "size": 30959,
    "path": "../public/server/assets/StoryBookReader-DcQ0f9R1.js"
  },
  "/server/assets/success-CreUDPMm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d07-s8HzvvyB29QDwHXCxzy0VAAxxmc"',
    "mtime": "2026-06-06T20:01:16.550Z",
    "size": 3335,
    "path": "../public/server/assets/success-CreUDPMm.js"
  },
  "/server/assets/subscriptions-BIwZDbf6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1ec-Bko9V5I6+seF9Znp3BUw8/CUXvE"',
    "mtime": "2026-06-06T20:01:16.550Z",
    "size": 492,
    "path": "../public/server/assets/subscriptions-BIwZDbf6.js"
  },
  "/server/assets/_tanstack-start-manifest_v-BBY-7Flq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"76f-wCYTa6fMMrveoDp58CkVzlJ9+eo"',
    "mtime": "2026-06-06T20:01:16.549Z",
    "size": 1903,
    "path": "../public/server/assets/_tanstack-start-manifest_v-BBY-7Flq.js"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _znUY8x = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_tRk7fS = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_tRk7fS };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_znUY8x)
].filter(Boolean);
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function createNitroApp() {
  const hooks = void 0;
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({
          error,
          context: errorCtx
        });
      }
    }
  };
  const h3App = createH3App({ onError(error, event) {
    return errorHandler(error, event);
  } });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  const app = {
    fetch: appHandler,
    h3: h3App,
    hooks,
    captureError
  };
  return app;
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  {
    h3App["~getMiddleware"] = (event, route) => {
      const pathname = event.url.pathname;
      const method = event.req.method;
      const middleware = [];
      {
        const routeRules = getRouteRules(method, pathname);
        event.context.routeRules = routeRules?.routeRules;
        if (routeRules?.routeRuleMiddleware.length) {
          middleware.push(...routeRules.routeRuleMiddleware);
        }
      }
      middleware.push(...h3App["~middleware"]);
      if (route?.data?.middleware?.length) {
        middleware.push(...route.data.middleware);
      }
      return middleware;
    };
  }
  return h3App;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
