import { a as apiRequest, g as getToken, A as ApiError, b as getApiBaseUrl } from "./router-HBU99EUm.js";
import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import * as React from "react";
import { useState, useEffect, useCallback, useMemo } from "react";
import { ArrowLeft, ArrowRight, Type, Minimize2, Maximize2, X, ChevronLeft, ChevronRight, Loader2, Sparkles } from "lucide-react";
import useEmblaCarousel from "embla-carousel-react";
import { c as cn, B as Button } from "./Footer-BcknXXCV.js";
async function generateAdventurePack(childId, theme, options) {
  return apiRequest(
    "/api/adventure-packs/generate",
    {
      method: "POST",
      body: JSON.stringify({
        childId,
        theme,
        optionalStoryNotes: options?.optionalStoryNotes?.trim() || void 0,
        storyLanguage: options?.storyLanguage || "en"
      })
    }
  );
}
async function generatePackPdf(packId) {
  return apiRequest(
    `/api/adventure-packs/${packId}/generate-pdf`,
    {
      method: "POST"
    }
  );
}
async function listAdventurePacks() {
  return apiRequest("/api/adventure-packs");
}
async function getAdventurePack(id) {
  return apiRequest(`/api/adventure-packs/${id}`);
}
function getDownloadUrl(packId) {
  return `${getApiBaseUrl()}/api/adventure-packs/${packId}/download`;
}
async function fetchIllustrationObjectUrl(illustrationPath) {
  const token = getToken();
  const response = await fetch(`${getApiBaseUrl()}${illustrationPath}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
  if (!response.ok) {
    throw new ApiError("Could not load illustration.", response.status);
  }
  const blob = await response.blob();
  return URL.createObjectURL(blob);
}
async function downloadAdventurePack(packId, fileName = "storybook.pdf") {
  const token = getToken();
  const response = await fetch(getDownloadUrl(packId), {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
  if (!response.ok) {
    let message = "Could not download PDF.";
    try {
      const text = await response.text();
      if (text) message = text;
    } catch {
    }
    throw new ApiError(message, response.status);
  }
  const blob = await response.blob();
  const objectUrl = URL.createObjectURL(blob);
  try {
    const anchor = document.createElement("a");
    anchor.href = objectUrl;
    anchor.download = fileName;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}
function parseProgressPercent(message) {
  if (!message) return null;
  const match = message.match(/~?(\d{1,3})%/);
  if (!match) return null;
  return Math.min(100, Math.max(0, parseInt(match[1], 10)));
}
function parseIllustrationPageProgress(message) {
  if (!message) return null;
  const match = message.match(/page\s+(\d+)\s+of\s+(\d+)/i);
  if (!match) return null;
  const current = parseInt(match[1], 10);
  const total = parseInt(match[2], 10);
  if (!total) return null;
  return Math.min(95, Math.round(35 + current / total * 60));
}
function isPackReadable(pack) {
  if (pack.status === "Failed") return false;
  if (pack.status === "Completed") {
    return (pack.storyPages?.length ?? 0) > 0;
  }
  if (pack.status !== "StoryReady") return false;
  const pages = pack.storyPages ?? [];
  return pages.length > 0 && pages.every((p) => p.isIllustrated);
}
function isPackIllustrating(pack) {
  return pack.status === "StoryReady" && !isPackReadable(pack);
}
function computePackProgressPercent(pack) {
  if (pack.status === "Completed") return 100;
  if (pack.status === "Failed") return 0;
  const parsed = parseProgressPercent(pack.progressMessage);
  if (parsed !== null) return parsed;
  const illustrationProgress = parseIllustrationPageProgress(pack.progressMessage);
  if (illustrationProgress !== null) return illustrationProgress;
  if (pack.status === "StoryReady") {
    const pages = pack.storyPages ?? [];
    const total = pack.storyPageCount ?? (pages.length || 6);
    const done = pages.filter((p) => p.isIllustrated).length;
    if (total > 0) return Math.min(95, Math.round(35 + done / total * 60));
    return 40;
  }
  if (pack.status === "GeneratingPdf") return 92;
  if (pack.status === "GeneratingStory" || pack.status === "Generating") return 22;
  if (pack.status === "Pending") return 8;
  return 15;
}
const IN_PROGRESS_STATUSES = [
  "Pending",
  "Generating",
  "GeneratingStory",
  "GeneratingPdf"
];
function isPackInProgress(status) {
  return IN_PROGRESS_STATUSES.includes(status);
}
function isPackGenerating(pack) {
  return isPackInProgress(pack.status) || isPackIllustrating(pack);
}
async function pollAdventurePack(id, onProgress, options) {
  const intervalMs = options?.intervalMs ?? 2e3;
  const maxAttempts = options?.maxAttempts ?? 240;
  const untilStatus = options?.untilStatus ?? "Completed";
  const untilReadable = options?.untilReadable ?? false;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const pack = await getAdventurePack(id);
    onProgress?.(pack);
    if (untilReadable) {
      if (isPackReadable(pack)) return pack;
    } else if (pack.status === untilStatus) {
      return pack;
    }
    if (pack.status === "Failed") {
      throw new Error(pack.errorMessage ?? pack.progressMessage ?? "Generation failed. Please try again.");
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  throw new Error(
    "Still working — your book is saved in My Books. Refresh there in a few minutes."
  );
}
async function listChildren() {
  return apiRequest("/api/children");
}
async function createChild(name, age, photoFile) {
  const form = new FormData();
  form.append("name", name);
  form.append("age", String(age));
  if (photoFile) {
    form.append("photo", photoFile);
  }
  return apiRequest("/api/children", {
    method: "POST",
    body: form
  });
}
const CarouselContext = React.createContext(null);
function useCarousel() {
  const context = React.useContext(CarouselContext);
  if (!context) {
    throw new Error("useCarousel must be used within a <Carousel />");
  }
  return context;
}
const Carousel = React.forwardRef(({ orientation = "horizontal", opts, setApi, plugins, className, children, ...props }, ref) => {
  const [carouselRef, api] = useEmblaCarousel(
    {
      ...opts,
      axis: orientation === "horizontal" ? "x" : "y"
    },
    plugins
  );
  const [canScrollPrev, setCanScrollPrev] = React.useState(false);
  const [canScrollNext, setCanScrollNext] = React.useState(false);
  const onSelect = React.useCallback((api2) => {
    if (!api2) {
      return;
    }
    setCanScrollPrev(api2.canScrollPrev());
    setCanScrollNext(api2.canScrollNext());
  }, []);
  const scrollPrev = React.useCallback(() => {
    api?.scrollPrev();
  }, [api]);
  const scrollNext = React.useCallback(() => {
    api?.scrollNext();
  }, [api]);
  const handleKeyDown = React.useCallback(
    (event) => {
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        scrollPrev();
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        scrollNext();
      }
    },
    [scrollPrev, scrollNext]
  );
  React.useEffect(() => {
    if (!api || !setApi) {
      return;
    }
    setApi(api);
  }, [api, setApi]);
  React.useEffect(() => {
    if (!api) {
      return;
    }
    onSelect(api);
    api.on("reInit", onSelect);
    api.on("select", onSelect);
    return () => {
      api?.off("select", onSelect);
    };
  }, [api, onSelect]);
  return /* @__PURE__ */ jsx(
    CarouselContext.Provider,
    {
      value: {
        carouselRef,
        api,
        opts,
        orientation: orientation || (opts?.axis === "y" ? "vertical" : "horizontal"),
        scrollPrev,
        scrollNext,
        canScrollPrev,
        canScrollNext
      },
      children: /* @__PURE__ */ jsx(
        "div",
        {
          ref,
          onKeyDownCapture: handleKeyDown,
          className: cn("relative", className),
          role: "region",
          "aria-roledescription": "carousel",
          ...props,
          children
        }
      )
    }
  );
});
Carousel.displayName = "Carousel";
const CarouselContent = React.forwardRef(
  ({ className, ...props }, ref) => {
    const { carouselRef, orientation } = useCarousel();
    return /* @__PURE__ */ jsx("div", { ref: carouselRef, className: "overflow-hidden", children: /* @__PURE__ */ jsx(
      "div",
      {
        ref,
        className: cn(
          "flex",
          orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col",
          className
        ),
        ...props
      }
    ) });
  }
);
CarouselContent.displayName = "CarouselContent";
const CarouselItem = React.forwardRef(
  ({ className, ...props }, ref) => {
    const { orientation } = useCarousel();
    return /* @__PURE__ */ jsx(
      "div",
      {
        ref,
        role: "group",
        "aria-roledescription": "slide",
        className: cn(
          "min-w-0 shrink-0 grow-0 basis-full",
          orientation === "horizontal" ? "pl-4" : "pt-4",
          className
        ),
        ...props
      }
    );
  }
);
CarouselItem.displayName = "CarouselItem";
const CarouselPrevious = React.forwardRef(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollPrev, canScrollPrev } = useCarousel();
    return /* @__PURE__ */ jsxs(
      Button,
      {
        ref,
        variant,
        size,
        className: cn(
          "absolute  h-8 w-8 rounded-full",
          orientation === "horizontal" ? "-left-12 top-1/2 -translate-y-1/2" : "-top-12 left-1/2 -translate-x-1/2 rotate-90",
          className
        ),
        disabled: !canScrollPrev,
        onClick: scrollPrev,
        ...props,
        children: [
          /* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Previous slide" })
        ]
      }
    );
  }
);
CarouselPrevious.displayName = "CarouselPrevious";
const CarouselNext = React.forwardRef(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollNext, canScrollNext } = useCarousel();
    return /* @__PURE__ */ jsxs(
      Button,
      {
        ref,
        variant,
        size,
        className: cn(
          "absolute h-8 w-8 rounded-full",
          orientation === "horizontal" ? "-right-12 top-1/2 -translate-y-1/2" : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90",
          className
        ),
        disabled: !canScrollNext,
        onClick: scrollNext,
        ...props,
        children: [
          /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Next slide" })
        ]
      }
    );
  }
);
CarouselNext.displayName = "CarouselNext";
const THEME_TINTS = {
  Airplanes: "var(--sky-soft)",
  Dinosaurs: "var(--mint)",
  Space: "var(--accent)",
  Pirates: "var(--sun)",
  Animals: "var(--sun)"
};
const FONT_SIZE_KEY = "storybook-font-size";
const FONT_SIZE_STYLES = {
  sm: { body: "text-sm leading-relaxed", title: "text-lg" },
  md: { body: "text-base leading-relaxed", title: "text-xl" },
  lg: { body: "text-lg leading-relaxed", title: "text-2xl" }
};
function loadFontSize() {
  if (typeof window === "undefined") return "md";
  const stored = localStorage.getItem(FONT_SIZE_KEY);
  return stored === "sm" || stored === "lg" ? stored : "md";
}
function isPublicIllustrationUrl(url) {
  if (url.startsWith("/api/")) {
    return false;
  }
  return url.startsWith("/public/") || url.startsWith("/demo/") || url.startsWith("http://") || url.startsWith("https://") || url.startsWith("data:");
}
function PageIllustration({
  page,
  pageIndex,
  previewStatus,
  themeTint,
  totalPages,
  variant = "default",
  onOpenFullscreen
}) {
  const [imageUrl, setImageUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const painting = !page.isIllustrated && (previewStatus === "Generating" || previewStatus === "None" || previewStatus === "Failed");
  useEffect(() => {
    if (!page.isIllustrated || !page.illustrationUrl) {
      setImageUrl(null);
      return;
    }
    if (isPublicIllustrationUrl(page.illustrationUrl)) {
      setImageUrl(page.illustrationUrl);
      setLoading(false);
      setError(false);
      return;
    }
    let cancelled = false;
    let objectUrl = null;
    setLoading(true);
    setError(false);
    void fetchIllustrationObjectUrl(page.illustrationUrl).then((url) => {
      if (cancelled) {
        URL.revokeObjectURL(url);
        return;
      }
      objectUrl = url;
      setImageUrl(url);
    }).catch(() => {
      if (!cancelled) setError(true);
    }).finally(() => {
      if (!cancelled) setLoading(false);
    });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [page.illustrationUrl, page.isIllustrated, previewStatus]);
  const imageClassName = variant === "fullscreen" ? "w-full max-h-[min(70vh,720px)] object-contain rounded-t-2xl bg-black/5" : "aspect-[4/3] w-full object-cover rounded-t-2xl";
  if (loading && !imageUrl && !error) {
    return /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "w-full rounded-t-2xl flex flex-col items-center justify-center gap-2",
          variant === "fullscreen" ? "min-h-[40vh]" : "aspect-[4/3]"
        ),
        style: { background: `color-mix(in oklab, ${themeTint} 55%, white)` },
        children: [
          /* @__PURE__ */ jsx(Loader2, { className: "h-8 w-8 animate-spin text-primary" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-muted-foreground", children: "Loading illustration…" })
        ]
      }
    );
  }
  if (error && page.isIllustrated) {
    return /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "w-full rounded-t-2xl flex flex-col items-center justify-center gap-2 px-4 text-center",
          variant === "fullscreen" ? "min-h-[40vh]" : "aspect-[4/3]"
        ),
        style: { background: `color-mix(in oklab, ${themeTint} 40%, white)` },
        children: [
          /* @__PURE__ */ jsx(Sparkles, { className: "h-8 w-8 text-primary/50" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-muted-foreground", children: "Illustration could not load" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Refresh the page or try again in a moment" })
        ]
      }
    );
  }
  if (imageUrl && !error) {
    return /* @__PURE__ */ jsxs(
      "button",
      {
        type: "button",
        onClick: onOpenFullscreen,
        className: "group relative block w-full rounded-t-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
        "aria-label": "View illustration fullscreen",
        children: [
          /* @__PURE__ */ jsx("img", { src: imageUrl, alt: "", className: imageClassName }),
          variant === "default" && onOpenFullscreen && /* @__PURE__ */ jsxs("span", { className: "absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-black/55 px-2.5 py-1 text-xs font-semibold text-white opacity-0 transition group-hover:opacity-100 group-focus-visible:opacity-100", children: [
            /* @__PURE__ */ jsx(Maximize2, { className: "h-3.5 w-3.5" }),
            "Fullscreen"
          ] })
        ]
      }
    );
  }
  if (painting) {
    return /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "w-full rounded-t-2xl flex flex-col items-center justify-center gap-2 px-4 text-center",
          variant === "fullscreen" ? "min-h-[40vh]" : "aspect-[4/3]"
        ),
        style: { background: `color-mix(in oklab, ${themeTint} 55%, white)` },
        children: [
          /* @__PURE__ */ jsx(Loader2, { className: "h-8 w-8 animate-spin text-primary" }),
          /* @__PURE__ */ jsxs("p", { className: "text-sm font-medium text-muted-foreground", children: [
            "Painting page ",
            pageIndex + 1,
            "…"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground/80", children: [
            "Page ",
            pageIndex + 1,
            " of ",
            totalPages,
            " · about 1 minute each"
          ] })
        ]
      }
    );
  }
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: cn(
        "w-full rounded-t-2xl flex items-center justify-center",
        variant === "fullscreen" ? "min-h-[40vh]" : "aspect-[4/3]"
      ),
      style: { background: `color-mix(in oklab, ${themeTint} 50%, white)` },
      children: /* @__PURE__ */ jsx(Sparkles, { className: "h-8 w-8 text-primary/40" })
    }
  );
}
function StoryBookReader({
  pages,
  theme,
  title,
  childName,
  previewIllustrationStatus = "None",
  isCompleted = false,
  storiesRemainingThisMonth,
  bookCredits = 0,
  className
}) {
  const [api, setApi] = useState();
  const [current, setCurrent] = useState(0);
  const [fontSize, setFontSize] = useState("md");
  useEffect(() => {
    setFontSize(loadFontSize());
  }, []);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const themeTint = THEME_TINTS[theme];
  const typography = FONT_SIZE_STYLES[fontSize];
  const variant = isFullscreen ? "fullscreen" : "default";
  const onSelect = useCallback(() => {
    if (!api) return;
    setCurrent(api.selectedScrollSnap());
  }, [api]);
  useEffect(() => {
    if (!api) return;
    onSelect();
    api.on("select", onSelect);
    return () => {
      api.off("select", onSelect);
    };
  }, [api, onSelect]);
  useEffect(() => {
    if (!isFullscreen) return;
    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        setIsFullscreen(false);
      }
    };
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [isFullscreen]);
  const cycleFontSize = () => {
    const next = fontSize === "sm" ? "md" : fontSize === "md" ? "lg" : "sm";
    setFontSize(next);
    localStorage.setItem(FONT_SIZE_KEY, next);
  };
  const allIllustrated = useMemo(() => pages.every((p) => p.isIllustrated), [pages]);
  const showPdfUpsell = !isCompleted && allIllustrated && !isFullscreen;
  const onLastPage = current === pages.length - 1;
  const showCreditsUpsell = allIllustrated && !isFullscreen && typeof storiesRemainingThisMonth === "number" && storiesRemainingThisMonth === 0;
  const showCreditsReminder = allIllustrated && !isFullscreen && typeof storiesRemainingThisMonth === "number" && storiesRemainingThisMonth > 0 && bookCredits === 0 && onLastPage;
  if (pages.length === 0) {
    return null;
  }
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: cn(
        "w-full",
        isFullscreen && "fixed inset-0 z-50 overflow-y-auto bg-background",
        className
      ),
      children: /* @__PURE__ */ jsxs(
        "div",
        {
          className: cn(
            "w-full",
            isFullscreen && "mx-auto flex min-h-full max-w-4xl flex-col p-4 sm:p-6 md:p-8"
          ),
          children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2 mb-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsx("p", { className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground truncate", children: childName ? `${childName}'s story` : "Your story" }),
                /* @__PURE__ */ jsx("p", { className: "font-display font-semibold truncate", children: title })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex shrink-0 items-center gap-2", children: [
                /* @__PURE__ */ jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: cycleFontSize,
                    className: "inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-semibold hover:bg-secondary transition",
                    title: "Change text size",
                    children: [
                      /* @__PURE__ */ jsx(Type, { className: "h-3.5 w-3.5" }),
                      fontSize === "sm" ? "Cozy" : fontSize === "md" ? "Default" : "Large"
                    ]
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsFullscreen((open) => !open),
                    className: "inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-semibold hover:bg-secondary transition",
                    title: isFullscreen ? "Exit fullscreen" : "Enter fullscreen",
                    children: isFullscreen ? /* @__PURE__ */ jsxs(Fragment, { children: [
                      /* @__PURE__ */ jsx(Minimize2, { className: "h-3.5 w-3.5" }),
                      "Exit"
                    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                      /* @__PURE__ */ jsx(Maximize2, { className: "h-3.5 w-3.5" }),
                      "Fullscreen"
                    ] })
                  }
                ),
                isFullscreen && /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsFullscreen(false),
                    className: "inline-flex items-center justify-center rounded-full border border-border bg-card p-2 hover:bg-secondary transition",
                    "aria-label": "Close fullscreen",
                    children: /* @__PURE__ */ jsx(X, { className: "h-4 w-4" })
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex flex-wrap items-center justify-center gap-2 mb-3", children: pages.map((page, index) => /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => api?.scrollTo(index),
                className: cn(
                  "rounded-full px-3 py-1.5 text-xs font-semibold border transition",
                  index === current ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground border-border hover:bg-secondary"
                ),
                children: [
                  "Page ",
                  index + 1,
                  !page.isIllustrated ? " …" : ""
                ]
              },
              `tab-${index}`
            )) }),
            /* @__PURE__ */ jsx("p", { className: "text-center text-xs text-muted-foreground mb-3", children: allIllustrated ? "Every page is illustrated — swipe or tap a page number." : "We're painting every page from your child's photo. The raw upload stays private." }),
            /* @__PURE__ */ jsxs("div", { className: cn("relative", isFullscreen ? "px-12" : "px-10"), children: [
              /* @__PURE__ */ jsx(Carousel, { setApi, opts: { align: "start", loop: false }, className: "w-full", children: /* @__PURE__ */ jsx(CarouselContent, { children: pages.map((page, index) => /* @__PURE__ */ jsx(CarouselItem, { children: /* @__PURE__ */ jsxs(
                "article",
                {
                  className: "rounded-2xl border border-border bg-card shadow-card overflow-hidden",
                  style: {
                    background: `color-mix(in oklab, ${themeTint} 12%, var(--card))`
                  },
                  children: [
                    /* @__PURE__ */ jsx(
                      PageIllustration,
                      {
                        page,
                        pageIndex: index,
                        previewStatus: previewIllustrationStatus,
                        themeTint,
                        totalPages: pages.length,
                        variant,
                        onOpenFullscreen: () => setIsFullscreen(true)
                      }
                    ),
                    /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 sm:px-6 sm:py-5 border-t border-border/60 bg-card/95", children: [
                      /* @__PURE__ */ jsxs("p", { className: "text-xs font-semibold text-primary mb-1", children: [
                        "Page ",
                        index + 1,
                        " of ",
                        pages.length
                      ] }),
                      /* @__PURE__ */ jsx(
                        "h3",
                        {
                          className: cn(
                            "font-display font-semibold text-foreground text-pretty",
                            typography.title
                          ),
                          children: page.title
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        "p",
                        {
                          className: cn(
                            "mt-3 text-foreground/90 text-pretty whitespace-pre-wrap",
                            typography.body
                          ),
                          children: page.content
                        }
                      )
                    ] })
                  ]
                }
              ) }, `page-${index}`)) }) }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => api?.scrollPrev(),
                  disabled: current === 0,
                  className: "absolute left-0 top-[38%] -translate-y-1/2 grid place-items-center h-8 w-8 rounded-full border border-border bg-card shadow-soft disabled:opacity-30 hover:bg-secondary transition",
                  "aria-label": "Previous page",
                  children: /* @__PURE__ */ jsx(ChevronLeft, { className: "h-4 w-4" })
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => api?.scrollNext(),
                  disabled: current >= pages.length - 1,
                  className: "absolute right-0 top-[38%] -translate-y-1/2 grid place-items-center h-8 w-8 rounded-full border border-border bg-card shadow-soft disabled:opacity-30 hover:bg-secondary transition",
                  "aria-label": "Next page",
                  children: /* @__PURE__ */ jsx(ChevronRight, { className: "h-4 w-4" })
                }
              )
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex justify-center gap-1.5 mt-4", children: pages.map((_, index) => /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => api?.scrollTo(index),
                className: cn(
                  "h-2 rounded-full transition-all",
                  index === current ? "w-6 bg-primary" : "w-2 bg-border hover:bg-primary/40"
                ),
                "aria-label": `Go to page ${index + 1}`
              },
              `dot-${index}`
            )) }),
            showPdfUpsell && /* @__PURE__ */ jsxs(
              "div",
              {
                className: "mt-4 rounded-2xl border border-primary/20 p-4 text-center",
                style: { background: `color-mix(in oklab, ${themeTint} 25%, var(--card))` },
                children: [
                  /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-foreground", children: "Love your slideshow? Export a printable PDF — it's free." }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Open My Books and tap Export PDF when your story is ready." })
                ]
              }
            ),
            showCreditsReminder && /* @__PURE__ */ jsxs(
              "div",
              {
                className: "mt-4 rounded-2xl border border-amber-300/50 p-4 text-center",
                style: { background: `color-mix(in oklab, ${themeTint} 18%, var(--card))` },
                children: [
                  /* @__PURE__ */ jsxs("p", { className: "text-sm font-medium text-foreground", children: [
                    "You have ",
                    storiesRemainingThisMonth,
                    " free",
                    " ",
                    storiesRemainingThisMonth === 1 ? "story" : "stories",
                    " left this month."
                  ] }),
                  /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground mt-1", children: [
                    "Each story is a full ",
                    pages.length,
                    "-page illustrated book — not just one page."
                  ] })
                ]
              }
            ),
            showCreditsUpsell && /* @__PURE__ */ jsxs(
              "div",
              {
                className: "mt-4 rounded-2xl border border-amber-300/60 p-4 text-center",
                style: { background: `color-mix(in oklab, ${themeTint} 22%, var(--card))` },
                children: [
                  /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold text-foreground", children: "Want another adventure?" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground mt-1", children: [
                    "You've used your stories for this month. Buy book credits to create more full",
                    " ",
                    pages.length,
                    "-page illustrated storybooks — PDF export stays free."
                  ] }),
                  /* @__PURE__ */ jsx(
                    Link,
                    {
                      to: "/",
                      hash: "pricing",
                      className: "inline-flex mt-3 items-center rounded-full bg-primary text-primary-foreground px-5 py-2 text-xs font-semibold hover:opacity-90 transition",
                      children: "View book packs"
                    }
                  )
                ]
              }
            )
          ]
        }
      )
    }
  );
}
export {
  StoryBookReader as S,
  listChildren as a,
  isPackIllustrating as b,
  computePackProgressPercent as c,
  isPackReadable as d,
  generatePackPdf as e,
  downloadAdventurePack as f,
  getAdventurePack as g,
  createChild as h,
  isPackGenerating as i,
  generateAdventurePack as j,
  parseProgressPercent as k,
  listAdventurePacks as l,
  pollAdventurePack as p
};
