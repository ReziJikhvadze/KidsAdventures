import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { N as Nav, F as Footer } from "./Footer-oFmOtiDq.mjs";
import { d as Route$1, u as useAuth, A as ApiError } from "./router-B8qRGRuM.mjs";
import { a as confirmCheckoutSession } from "./subscriptions-C-hp6DLd.mjs";
import { b as LoaderCircle, J as CircleCheck } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "./BrandLogo-T23ohXas.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
function BillingSuccess() {
  const {
    session_id: sessionId
  } = Route$1.useSearch();
  const {
    refreshAccountBalance,
    user
  } = useAuth();
  const [confirming, setConfirming] = reactExports.useState(!!sessionId);
  const [credits, setCredits] = reactExports.useState(null);
  reactExports.useEffect(() => {
    if (!sessionId) {
      void refreshAccountBalance();
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const balance = await confirmCheckoutSession(sessionId);
        if (cancelled) return;
        setCredits(balance.bookCredits);
        await refreshAccountBalance();
      } catch (err) {
        if (cancelled) return;
        const message = err instanceof ApiError ? err.message : "Could not confirm payment. Try refreshing.";
        toast.error(message);
        await refreshAccountBalance();
      } finally {
        if (!cancelled) setConfirming(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [sessionId, refreshAccountBalance]);
  const displayCredits = credits ?? user?.bookCredits ?? 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background text-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "mx-auto max-w-lg px-6 py-24 text-center", children: [
      confirming ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-14 w-14 mx-auto text-primary mb-6 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-14 w-14 mx-auto text-primary mb-6" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-3xl font-bold", children: confirming ? "Confirming payment…" : "Payment successful" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-muted-foreground", children: confirming ? "Adding your book credits now." : `Your book credits have been added — you now have ${displayCredits} credit${displayCredits === 1 ? "" : "s"}. Open My Books and tap Create illustrated PDF on any story.` }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex flex-col sm:flex-row gap-3 justify-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/my-packs", className: "inline-flex items-center justify-center rounded-full bg-primary text-primary-foreground px-6 py-3 font-semibold hover:opacity-90 transition", children: "My books" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", hash: "pricing", className: "inline-flex items-center justify-center rounded-full border border-border px-6 py-3 font-semibold hover:bg-secondary transition", children: "View pricing" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
export {
  BillingSuccess as component
};
