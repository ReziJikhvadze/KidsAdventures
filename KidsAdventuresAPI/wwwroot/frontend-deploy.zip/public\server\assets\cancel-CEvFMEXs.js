import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { N as Nav, F as Footer } from "./Footer-BcknXXCV.js";
import "react";
import "lucide-react";
import "./BrandLogo-T23ohXas.js";
import "./router-HBU99EUm.js";
import "@tanstack/react-query";
import "sonner";
import "@radix-ui/react-dialog";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-label";
function BillingCancel() {
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-background text-foreground", children: [
    /* @__PURE__ */ jsx(Nav, {}),
    /* @__PURE__ */ jsxs("main", { className: "mx-auto max-w-lg px-6 py-24 text-center", children: [
      /* @__PURE__ */ jsx("h1", { className: "font-display text-3xl font-bold", children: "Checkout cancelled" }),
      /* @__PURE__ */ jsx("p", { className: "mt-4 text-muted-foreground", children: "No charge was made. You can still create free stories — buy book credits when you are ready for an illustrated PDF." }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 flex flex-col sm:flex-row gap-3 justify-center", children: [
        /* @__PURE__ */ jsx(Link, { to: "/", hash: "pricing", className: "inline-flex items-center justify-center rounded-full bg-primary text-primary-foreground px-6 py-3 font-semibold hover:opacity-90 transition", children: "View book packs" }),
        /* @__PURE__ */ jsx(Link, { to: "/", hash: "generator", className: "inline-flex items-center justify-center rounded-full border border-border px-6 py-3 font-semibold hover:bg-secondary transition", children: "Create a story" })
      ] })
    ] }),
    /* @__PURE__ */ jsx(Footer, {})
  ] });
}
export {
  BillingCancel as component
};
