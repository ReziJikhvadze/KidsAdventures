import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { N as Nav, F as Footer, A as AuthDialog, c as cn } from "./Footer-oFmOtiDq.mjs";
import { S as StoryBookReader, f as downloadAdventurePack, h as createChild, j as generateAdventurePack, p as pollAdventurePack, c as computePackProgressPercent, e as generatePackPdf, k as parseProgressPercent } from "./StoryBookReader-ntxFssvk.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as useAuth, A as ApiError, g as getToken } from "./router-B8qRGRuM.mjs";
import { c as createCheckoutSession } from "./subscriptions-C-hp6DLd.mjs";
import { R as Root2, I as Item, H as Header, T as Trigger2, C as Content2 } from "../_libs/radix-ui__react-accordion.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { A as ArrowRight, d as CirclePlay, e as Star, U as UserRound, f as Palette, D as Download, g as Sword, T as Telescope, h as Plane, W as WandSparkles, i as Brain, H as Heart, j as Compass, k as Crown, l as Shield, M as MapPin, m as Bone, n as Rocket, o as Ship, p as PawPrint, q as Check, r as Camera, s as Upload, t as ChevronDown, b as LoaderCircle, S as Sparkles, G as Gift, u as Lock, v as Tv, w as GraduationCap, x as Timer, B as BookOpen, y as Users } from "../_libs/lucide-react.mjs";
import "./BrandLogo-T23ohXas.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/embla-carousel-react.mjs";
import "../_libs/embla-carousel-reactive-utils.mjs";
import "../_libs/embla-carousel.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-collapsible.mjs";
import "../_libs/radix-ui__react-direction.mjs";
const heroImg = "/assets/hero-QPgGu4Uy.jpg";
function Hero() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-hero-glow opacity-90 pointer-events-none" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-grid opacity-40 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)] pointer-events-none" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative mx-auto max-w-7xl px-6 pt-16 pb-20 md:pt-24 md:pb-28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid lg:grid-cols-[1.05fr_1fr] gap-12 items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "animate-rise", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1 text-xs font-medium text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-flex h-1.5 w-1.5 rounded-full bg-primary" }),
          "New · AI-personalized adventure books"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "mt-5 font-display text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.02] text-balance", children: [
          "Personalized adventures your kids can",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "relative inline-block", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-10", children: "print and play" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute inset-x-0 bottom-1 h-3 bg-[color:var(--sun)]/70 -z-0 rounded" })
          ] }),
          "."
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-lg md:text-xl text-muted-foreground max-w-xl text-pretty", children: "Generate custom illustrated storybooks starring your child. Story in minutes — PDF when you are ready." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { id: "cta", className: "mt-8 flex flex-col sm:flex-row gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "a",
            {
              href: "#generator",
              className: "group inline-flex items-center justify-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3.5 font-semibold shadow-soft hover:translate-y-[-1px] transition",
              children: [
                "Create your book",
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4 transition group-hover:translate-x-0.5" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "a",
            {
              href: "#preview",
              className: "inline-flex items-center justify-center gap-2 rounded-full bg-card border border-border px-6 py-3.5 font-semibold hover:bg-secondary transition",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CirclePlay, { className: "h-4 w-4" }),
                "View Example"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex items-center gap-5 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1", children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            Star,
            {
              className: "h-4 w-4 fill-[color:var(--sun)] text-[color:var(--sun)]"
            },
            i
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Loved by 12,000+ parents this month" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative animate-rise [animation-delay:120ms]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -inset-6 rounded-[2rem] bg-[color:var(--sky-soft)]/60 -rotate-2" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative rounded-[2rem] bg-card shadow-card overflow-hidden border border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: heroImg,
            alt: "Open adventure book with paper airplanes, dinosaurs, stars and pirate ship illustrations",
            width: 1536,
            height: 1152,
            className: "w-full h-auto"
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute -bottom-5 -left-5 rounded-2xl bg-card border border-border shadow-card px-4 py-3 flex items-center gap-3 animate-float", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-9 w-9 rounded-full bg-[color:var(--mint)]/40 grid place-items-center font-display font-bold", children: "✓" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: "Pack ready" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground text-xs", children: "42 seconds" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-4 -right-3 rounded-full bg-primary text-primary-foreground text-xs font-semibold px-3 py-1.5 shadow-soft rotate-6", children: "For ages 4–12" })
      ] })
    ] }) })
  ] });
}
const steps = [
  {
    icon: UserRound,
    title: "Enter child details",
    desc: "Tell us your child's name and age so every page feels made just for them."
  },
  {
    icon: Palette,
    title: "Choose a theme",
    desc: "Airplanes, dinosaurs, space, pirates or animals — pick what they love most."
  },
  {
    icon: Download,
    title: "Download & print",
    desc: "Create an illustrated storybook PDF when you are ready — we email you when it is done."
  }
];
function HowItWorks() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "how", className: "relative py-24 md:py-32", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary tracking-wide uppercase", children: "How it works" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl md:text-5xl font-bold text-balance", children: "Three steps to an unforgettable afternoon." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-14 grid md:grid-cols-3 gap-6", children: steps.map((s, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "relative rounded-3xl bg-card border border-border p-8 shadow-soft hover:shadow-card transition group",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-4 left-8 inline-flex items-center justify-center h-8 w-8 rounded-full bg-foreground text-background text-xs font-bold font-display", children: i + 1 }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-12 w-12 rounded-2xl bg-secondary grid place-items-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition", children: /* @__PURE__ */ jsxRuntimeExports.jsx(s.icon, { className: "h-6 w-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-5 font-display text-2xl font-semibold", children: s.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-muted-foreground", children: s.desc })
        ]
      },
      s.title
    )) })
  ] }) });
}
const airplanes = "/assets/theme-airplanes-BRcmx3yh.jpg";
const dinosaurs = "/assets/theme-dinosaurs-Jy-PzUiV.jpg";
const space = "/assets/theme-space-XCcLprgr.jpg";
const pirates = "/assets/theme-pirates-ruqjfyS9.jpg";
const animals = "/assets/theme-animals-Dua5i12h.jpg";
const themes$1 = [
  { name: "Airplanes", desc: "Take to the skies", img: airplanes, tint: "var(--sky-soft)" },
  { name: "Dinosaurs", desc: "Roar into the past", img: dinosaurs, tint: "var(--mint)" },
  { name: "Space", desc: "Explore the stars", img: space, tint: "var(--accent)" },
  { name: "Pirates", desc: "Hunt the treasure", img: pirates, tint: "var(--sun)" },
  { name: "Animals", desc: "Meet the wild", img: animals, tint: "var(--sun)" }
];
function Themes() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "themes", className: "relative py-24 md:py-32 bg-secondary/40", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col md:flex-row md:items-end md:justify-between gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary tracking-wide uppercase", children: "Themes" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl md:text-5xl font-bold text-balance", children: "Pick the world they'll fall in love with." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground max-w-md", children: "Each theme is a full personalized story — and is personalized with your child's name on every page." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-12 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5", children: themes$1.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "group relative rounded-3xl bg-card border border-border overflow-hidden shadow-soft hover:shadow-card hover:-translate-y-1 transition",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "aspect-square p-4",
              style: { background: `color-mix(in oklab, ${t.tint} 35%, var(--card))` },
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: t.img,
                  alt: `${t.name} theme illustration`,
                  loading: "lazy",
                  width: 768,
                  height: 768,
                  className: "w-full h-full object-contain group-hover:scale-105 transition duration-500"
                }
              )
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-lg font-semibold", children: t.name }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground", children: t.desc })
          ] })
        ]
      },
      t.name
    )) })
  ] }) });
}
const demoPages = [
  {
    title: "The Skyward Quest Begins",
    content: "When Leo looked out the window, the clouds had shaped themselves into airplanes — and one of them had his name painted on the side in golden letters.",
    isIllustrated: true,
    illustrationUrl: "/demo/demo-page-1.png"
  },
  {
    title: "Through the Cloud Kingdom",
    content: "The friendly captain handed Leo a map made of starlight. Every page of your book can look like this — with a unique illustration starring your child.",
    isIllustrated: true,
    illustrationUrl: "/demo/demo-page-2.png"
  },
  {
    title: "A Hero's Landing",
    content: "Leo landed softly on a runway of rainbow light. Mom and Dad cheered from the observation deck as the adventure came to a happy end.",
    isIllustrated: true,
    illustrationUrl: "/demo/demo-page-3.png"
  }
];
function Preview() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "preview", className: "relative py-24 md:py-32", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto max-w-7xl px-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid lg:grid-cols-2 gap-12 items-start", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary tracking-wide uppercase", children: "Preview" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl md:text-5xl font-bold text-balance", children: "Read like a real picture book." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-muted-foreground text-pretty", children: "Every story is a 6-page picture book with warm, animated-style illustrations on every page. PDF export is free — book credits unlock extra stories." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-6 space-y-3 text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4 text-primary mt-0.5 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-foreground", children: "Illustrated slideshow free" }),
            " — swipe through every painted page before you buy."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-4 w-4 text-muted-foreground mt-0.5 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-foreground", children: "PDF export is free" }),
            " — download, print, and share anytime."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-primary font-display font-bold mt-0.5", children: "Aa" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Adjustable text size for bedtime read-aloud on phone or tablet." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "absolute -inset-4 rounded-3xl opacity-60 pointer-events-none",
          style: { background: "color-mix(in oklab, var(--sky-soft) 40%, transparent)" }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-3xl border border-border bg-card p-4 sm:p-6 shadow-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-semibold text-center text-muted-foreground mb-4 uppercase tracking-wide", children: "Demo · swipe the pages · try fullscreen" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          StoryBookReader,
          {
            pages: demoPages,
            theme: "Airplanes",
            title: "Leo's Sky Adventure",
            childName: "Leo",
            previewIllustrationStatus: "Ready",
            isCompleted: false
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-center text-xs text-muted-foreground", children: "Sample story with demo art — your book uses your child's photo and name." })
      ] })
    ] })
  ] }) }) });
}
const items = [
  { icon: Tv, title: "Screen-free play", desc: "Hours away from tablets and TV." },
  {
    icon: GraduationCap,
    title: "Educational & fun",
    desc: "Reading, problem-solving and creativity in one."
  },
  {
    icon: Heart,
    title: "Personal for every child",
    desc: "Their name, age and interests on every page."
  },
  { icon: Timer, title: "Ready in under a minute", desc: "Generate, print, and you're set to go." }
];
function Benefits() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "relative py-24 md:py-32 bg-secondary/40", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary tracking-wide uppercase", children: "Why parents love it" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl md:text-5xl font-bold text-balance", children: "Made to delight kids — and give you a break." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5", children: items.map((it) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "rounded-3xl bg-card border border-border p-6 shadow-soft",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-11 w-11 rounded-xl bg-[color:var(--sky-soft)]/70 grid place-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(it.icon, { className: "h-5 w-5 text-foreground" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-5 font-display text-xl font-semibold", children: it.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-muted-foreground text-sm", children: it.desc })
        ]
      },
      it.title
    )) })
  ] }) });
}
const plans = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    desc: "Try a personalized story — no card needed.",
    features: [
      "1 story per month (text)",
      "All 5 core themes",
      "Read in the app",
      "Illustrated PDF requires a book pack"
    ],
    cta: "Create free story",
    highlighted: false,
    action: "free",
    icon: Sparkles
  },
  {
    name: "3 Books",
    price: "$14.99",
    period: "one-time",
    desc: "Three illustrated storybook PDFs.",
    features: [
      "3 illustrated PDF credits",
      "Never expires",
      "Photo-personalized hero",
      "Print-ready downloads"
    ],
    cta: "Buy 3 books",
    highlighted: false,
    action: "Books3",
    icon: BookOpen
  },
  {
    name: "5 Books",
    price: "$23.99",
    period: "one-time",
    desc: "Best value for siblings or repeat adventures.",
    features: [
      "5 illustrated PDF credits",
      "Never expires",
      "All themes & languages",
      "Family cast in stories"
    ],
    cta: "Buy 5 books",
    highlighted: true,
    action: "Books5",
    icon: BookOpen,
    badge: "Most popular"
  },
  {
    name: "15 Books",
    price: "$62.99",
    period: "one-time",
    desc: "For families, classrooms, or big gift seasons.",
    features: [
      "15 illustrated PDF credits",
      "Never expires",
      "Lowest price per book",
      "Perfect for grandparents"
    ],
    cta: "Buy 15 books",
    highlighted: false,
    action: "Books15",
    icon: Users,
    badge: "Best value"
  }
];
function Pricing() {
  const { isAuthenticated, refreshAccountBalance } = useAuth();
  const [authOpen, setAuthOpen] = reactExports.useState(false);
  const [pendingPlan, setPendingPlan] = reactExports.useState(null);
  const [checkingOut, setCheckingOut] = reactExports.useState(null);
  const startCheckout = async (plan) => {
    setCheckingOut(plan);
    try {
      const session = await createCheckoutSession(plan);
      if (session.checkoutUrl) {
        window.location.href = session.checkoutUrl;
        return;
      }
      toast.error("Checkout URL was not returned.");
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Could not start checkout.";
      toast.error(message);
    } finally {
      setCheckingOut(null);
    }
  };
  const handleCta = (action) => {
    if (action === "free") {
      document.getElementById("generator")?.scrollIntoView({ behavior: "smooth" });
      return;
    }
    if (!isAuthenticated) {
      setPendingPlan(action);
      setAuthOpen(true);
      return;
    }
    void startCheckout(action);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      AuthDialog,
      {
        open: authOpen,
        onOpenChange: setAuthOpen,
        defaultMode: "login",
        onSuccess: () => {
          void refreshAccountBalance();
          if (pendingPlan) {
            const plan = pendingPlan;
            setPendingPlan(null);
            void startCheckout(plan);
          }
        }
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "pricing", className: "relative py-24 md:py-32", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl mx-auto text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary tracking-wide uppercase", children: "Pricing" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl md:text-5xl font-bold text-balance", children: "Free stories. Pay only for illustrated books." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-muted-foreground", children: "Creating a story is free. Each illustrated PDF uses one book credit — buy packs of 3, 5, or 15 and use them whenever you want." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-14 grid md:grid-cols-2 xl:grid-cols-4 gap-6 max-w-7xl mx-auto", children: plans.map((p) => {
        const Icon = p.icon;
        const isLoading = p.action !== "free" && checkingOut === p.action;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `relative rounded-3xl p-8 border flex flex-col ${p.highlighted ? "bg-foreground text-background border-foreground shadow-card" : "bg-card border-border shadow-soft"}`,
            children: [
              p.badge && /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: `absolute -top-3 left-8 inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${p.highlighted ? "bg-primary text-primary-foreground" : "bg-foreground text-background"}`,
                  children: p.badge
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `grid place-items-center h-8 w-8 rounded-lg ${p.highlighted ? "bg-background/15" : "bg-primary/10 text-primary"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-xl font-semibold", children: p.name })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-baseline gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-display text-5xl font-bold", children: p.price }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: p.highlighted ? "text-background/70" : "text-muted-foreground",
                    children: p.period
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "p",
                {
                  className: `mt-2 ${p.highlighted ? "text-background/70" : "text-muted-foreground"}`,
                  children: p.desc
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-6 space-y-3 flex-1", children: p.features.map((f) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3 text-sm", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `mt-0.5 grid place-items-center h-5 w-5 rounded-full ${p.highlighted ? "bg-background/15 text-background" : "bg-secondary text-primary"}`,
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-3 w-3" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: f })
              ] }, f)) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  onClick: () => handleCta(p.action),
                  disabled: isLoading,
                  className: `mt-8 w-full rounded-full py-3 font-semibold transition disabled:opacity-60 ${p.highlighted ? "bg-primary text-primary-foreground hover:opacity-90" : "bg-foreground text-background hover:opacity-90"}`,
                  children: isLoading ? "Redirecting…" : p.cta
                }
              )
            ]
          },
          p.name
        );
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-8 text-center text-xs text-muted-foreground max-w-2xl mx-auto", children: "One illustrated book uses 1 credit. Credits never expire. At roughly $4–$5 per book, packs cover our illustration costs with room to grow the product." })
    ] }) })
  ] });
}
const Accordion = Root2;
const AccordionItem = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(Item, { ref, className: cn("border-b", className), ...props }));
AccordionItem.displayName = "AccordionItem";
const AccordionTrigger = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(Header, { className: "flex", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
  Trigger2,
  {
    ref,
    className: cn(
      "flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180",
      className
    ),
    ...props,
    children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })
    ]
  }
) }));
AccordionTrigger.displayName = Trigger2.displayName;
const AccordionContent = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Content2,
  {
    ref,
    className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
    ...props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("pb-4 pt-0", className), children })
  }
));
AccordionContent.displayName = Content2.displayName;
const faqs = [
  {
    q: "How is each adventure pack personalized?",
    a: "We weave your child's name and age into a personalized story, and tailor the language to their age group (3–12)."
  },
  {
    q: "How long does it take to generate a pack?",
    a: "Your illustrated slideshow is usually ready in a few minutes. PDF export reuses those pictures and takes about 30 seconds."
  },
  {
    q: "What do I need to print at home?",
    a: "Any standard color printer and A4 or US Letter paper. Coloring pages also work great in black and white."
  },
  {
    q: "Is the content kid-safe?",
    a: "Yes. All stories are reviewed by our editorial team and filtered for age-appropriate language and themes."
  },
  {
    q: "How do book credits work?",
    a: "Stories are free to create and read. Each illustrated PDF uses one book credit. Buy a 3, 5, or 15 book pack — credits never expire."
  },
  {
    q: "Do you offer refunds?",
    a: "If an illustrated PDF fails after using a credit, we restore the credit automatically. Contact us if you are unhappy with a completed book."
  }
];
function FAQ() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "faq", className: "relative py-24 md:py-32 bg-secondary/40", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-3xl px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary tracking-wide uppercase", children: "FAQ" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl md:text-5xl font-bold text-balance", children: "Questions, answered." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Accordion, { type: "single", collapsible: true, className: "mt-12 space-y-3", children: faqs.map((f, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      AccordionItem,
      {
        value: `item-${i}`,
        className: "rounded-2xl bg-card border border-border px-5 shadow-soft",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(AccordionTrigger, { className: "text-left font-display text-lg font-semibold hover:no-underline", children: f.q }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AccordionContent, { className: "text-muted-foreground", children: f.a })
        ]
      },
      i
    )) })
  ] }) });
}
const THEME_ID_TO_API = {
  airplanes: "Airplanes",
  dinosaurs: "Dinosaurs",
  space: "Space",
  pirates: "Pirates",
  animals: "Animals"
};
function dataUrlToFile(dataUrl, filename) {
  const [header, base64] = dataUrl.split(",");
  const mime = header.match(/:(.*?);/)?.[1] ?? "image/jpeg";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new File([bytes], filename, { type: mime });
}
const themes = [
  { id: "airplanes", name: "Airplanes", icon: Plane, tint: "var(--sky-soft)" },
  { id: "dinosaurs", name: "Dinosaurs", icon: Bone, tint: "var(--mint)" },
  { id: "space", name: "Space", icon: Rocket, tint: "var(--accent)" },
  { id: "pirates", name: "Pirates", icon: Ship, tint: "var(--sun)" },
  { id: "animals", name: "Animals", icon: PawPrint, tint: "var(--sun)" }
];
const parentRoles = [
  { value: "captain", label: "The Captain", icon: Crown },
  { value: "navigator", label: "Chief Navigator", icon: Compass },
  { value: "guardian", label: "The Guardian", icon: Shield },
  { value: "explorer", label: "Lead Explorer", icon: MapPin }
];
const grandRoles = [
  { value: "wise", label: "The Wise One", icon: Brain },
  { value: "storykeeper", label: "Story Keeper", icon: Star },
  { value: "healer", label: "The Healer", icon: Heart },
  { value: "navigator", label: "Chief Navigator", icon: Compass }
];
const siblingRoles = [
  { value: "sidekick", label: "Co-Adventurer", icon: Sword },
  { value: "scout", label: "The Scout", icon: Telescope },
  { value: "pilot", label: "The Pilot", icon: Plane },
  { value: "engineer", label: "The Engineer", icon: WandSparkles }
];
const roleOptions = {
  mom: parentRoles,
  dad: parentRoles,
  grandma: grandRoles,
  grandpa: grandRoles,
  brother: siblingRoles,
  sister: siblingRoles,
  sibling: siblingRoles,
  friend: siblingRoles
};
const ENABLE_STORY_CAST = false;
const storyLanguages = [
  { value: "en", label: "English" },
  { value: "ka", label: "Georgian (ქართული)" },
  { value: "es", label: "Spanish (Español)" }
];
function Generator() {
  const [name, setName] = reactExports.useState("");
  const [age, setAge] = reactExports.useState("");
  const [childPhoto, setChildPhoto] = reactExports.useState(null);
  const [optionalNotes, setOptionalNotes] = reactExports.useState("");
  const [storyLanguage, setStoryLanguage] = reactExports.useState("en");
  const [theme, setTheme] = reactExports.useState(null);
  const [members, setMembers] = reactExports.useState([]);
  const [showOptional, setShowOptional] = reactExports.useState(false);
  const [status, setStatus] = reactExports.useState("idle");
  const [progress, setProgress] = reactExports.useState(0);
  const [progressMessage, setProgressMessage] = reactExports.useState(null);
  const [completedPackId, setCompletedPackId] = reactExports.useState(null);
  const [storyTitle, setStoryTitle] = reactExports.useState(null);
  const [storyPages, setStoryPages] = reactExports.useState([]);
  const [packTheme, setPackTheme] = reactExports.useState(null);
  const [previewIllustrationStatus, setPreviewIllustrationStatus] = reactExports.useState("None");
  const [downloading, setDownloading] = reactExports.useState(false);
  const [startingPdf, setStartingPdf] = reactExports.useState(false);
  const [errorMessage, setErrorMessage] = reactExports.useState(null);
  const [authOpen, setAuthOpen] = reactExports.useState(false);
  reactExports.useRef(null);
  const heroPhotoRef = reactExports.useRef(null);
  const { isAuthenticated, isLoading, canCreatePdf, refreshAccountBalance, setBookCredits, user } = useAuth();
  const ageValid = typeof age === "number" && !Number.isNaN(age) && age >= 3 && age <= 12;
  const missingRequirements = [];
  if (!name.trim()) missingRequirements.push("child's name");
  if (age === "" || typeof age === "number" && Number.isNaN(age)) {
    missingRequirements.push("age (3–12)");
  } else if (!ageValid) {
    missingRequirements.push("age between 3 and 12");
  }
  if (!theme) missingRequirements.push("a theme");
  const valid = missingRequirements.length === 0;
  const addHeroPhoto = (file) => {
    if (!file || file.size > 5 * 1024 * 1024) return;
    const reader = new FileReader();
    reader.onload = () => setChildPhoto(reader.result);
    reader.readAsDataURL(file);
  };
  members.map((m) => {
    if (!m.relation || !m.role) return null;
    const role = roleOptions[m.relation].find((r) => r.value === m.role);
    if (!role) return null;
    return { ...m, relation: m.relation, roleObj: role };
  }).filter(Boolean);
  const runGeneration = async () => {
    if (!valid || !theme) return;
    setStatus("generatingStory");
    setProgress(5);
    setProgressMessage("Saving your hero…");
    setErrorMessage(null);
    setCompletedPackId(null);
    setStoryTitle(null);
    setStoryPages([]);
    try {
      const apiTheme = THEME_ID_TO_API[theme];
      if (!apiTheme) throw new Error("Invalid theme selected.");
      setProgress(12);
      const heroFile = childPhoto?.startsWith("data:") ? dataUrlToFile(childPhoto, "hero.jpg") : void 0;
      const child = await createChild(name.trim(), age, heroFile);
      setProgress(20);
      if (ENABLE_STORY_CAST) ;
      setProgress(28);
      setProgressMessage("Creating your illustrated storybook…");
      const queued = await generateAdventurePack(child.id, apiTheme, {
        optionalStoryNotes: optionalNotes.trim() || void 0,
        storyLanguage
      });
      void refreshAccountBalance();
      const finished = await pollAdventurePack(
        queued.id,
        (pack) => {
          if (pack.progressMessage) {
            setProgressMessage(pack.progressMessage);
          }
          setProgress(computePackProgressPercent(pack));
        },
        { untilReadable: true, maxAttempts: 300 }
      );
      setCompletedPackId(finished.id);
      setStoryTitle(finished.title ?? null);
      setStoryPages(finished.storyPages ?? []);
      setPackTheme(finished.theme);
      setPreviewIllustrationStatus(finished.previewIllustrationStatus ?? "Ready");
      setProgress(100);
      setStatus("storyReady");
      await refreshAccountBalance();
      toast.success("Your illustrated storybook is ready!");
    } catch (err) {
      const message = err instanceof ApiError ? err.message : err instanceof Error ? err.message : "Failed to generate pack.";
      setErrorMessage(message);
      setStatus("error");
      toast.error(message);
    }
  };
  const generate = () => {
    if (!valid) return;
    if (isLoading) {
      toast.message("Checking your sign-in…");
      return;
    }
    if (!isAuthenticated || !getToken()) {
      setAuthOpen(true);
      toast.error("Please sign in to create a story.");
      return;
    }
    void runGeneration();
  };
  const runPdfGeneration = async () => {
    if (!completedPackId) return;
    setStartingPdf(true);
    setStatus("generatingPdf");
    setProgress(10);
    const slideshowReady = storyPages.length > 0 && storyPages.every((p) => p.isIllustrated);
    if (!slideshowReady) {
      toast.error("Wait until every page is illustrated, then export PDF.");
      setStatus("storyReady");
      setStartingPdf(false);
      return;
    }
    setProgressMessage("Building PDF from your slideshow… ~30 seconds");
    try {
      const queued = await generatePackPdf(completedPackId);
      if (typeof queued.bookCredits === "number") {
        setBookCredits(queued.bookCredits);
      } else {
        await refreshAccountBalance();
      }
      const completed = await pollAdventurePack(
        completedPackId,
        (pack) => {
          if (pack.progressMessage) {
            setProgressMessage(pack.progressMessage);
            const pct = parseProgressPercent(pack.progressMessage);
            if (pct !== null) setProgress(pct);
          }
        },
        {
          untilStatus: "Completed",
          maxAttempts: 30
        }
      );
      setStoryPages(completed.storyPages ?? storyPages);
      setPreviewIllustrationStatus(completed.previewIllustrationStatus ?? "Ready");
      setProgress(100);
      setStatus("done");
      await refreshAccountBalance();
      toast.success("Your storybook PDF is ready!");
    } catch (err) {
      const message = err instanceof ApiError ? err.message : err instanceof Error ? err.message : "PDF creation failed.";
      setErrorMessage(message);
      setStatus("storyReady");
      toast.error(message);
    } finally {
      setStartingPdf(false);
    }
  };
  const reset = () => {
    setStatus("idle");
    setProgress(0);
    setProgressMessage(null);
    setCompletedPackId(null);
    setStoryTitle(null);
    setStoryPages([]);
    setPackTheme(null);
    setPreviewIllustrationStatus("None");
    setErrorMessage(null);
  };
  const selectedTheme = themes.find((t) => t.id === theme);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      AuthDialog,
      {
        open: authOpen,
        onOpenChange: setAuthOpen,
        onSuccess: () => void runGeneration()
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "generator", className: "relative py-24 md:py-32 scroll-mt-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary tracking-wide uppercase", children: "Create your book" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 font-display text-4xl md:text-5xl font-bold text-balance", children: "A personalized story in minutes." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-muted-foreground", children: "Name, age, and theme — we write the story first. Add an illustrated PDF when you are ready." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-12 grid lg:grid-cols-[1.1fr_1fr] gap-8 items-start", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl bg-card border border-border shadow-card p-6 md:p-10", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-[2fr_1fr] gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-semibold", children: "Child's name" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  value: name,
                  maxLength: 40,
                  onChange: (e) => setName(e.target.value),
                  placeholder: "e.g. Leo",
                  className: "mt-2 w-full rounded-xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-semibold", children: "Age" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "number",
                  min: 3,
                  max: 12,
                  value: age,
                  onChange: (e) => setAge(e.target.value ? Number(e.target.value) : ""),
                  placeholder: "3–12",
                  className: "mt-2 w-full rounded-xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-semibold", children: "Choose a theme" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Airplanes, dinosaurs, space, pirates, or animals — pick one world for the whole book." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 grid grid-cols-2 sm:grid-cols-5 gap-2", children: themes.map((t) => {
              const active = theme === t.id;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => setTheme(t.id),
                  className: `relative rounded-2xl border p-3 flex flex-col items-center gap-2 transition ${active ? "border-primary bg-primary/5 ring-4 ring-primary/10" : "border-border bg-card hover:border-foreground/30"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: "h-10 w-10 rounded-xl grid place-items-center",
                        style: { background: `color-mix(in oklab, ${t.tint} 55%, white)` },
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(t.icon, { className: "h-5 w-5 text-foreground" })
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-semibold", children: t.name }),
                    active && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-primary text-primary-foreground grid place-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-3 w-3" }) })
                  ]
                },
                t.id
              );
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 rounded-2xl border border-border bg-secondary/30 p-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
              childPhoto ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: childPhoto,
                  alt: name || "Your child",
                  className: "h-16 w-16 rounded-xl object-cover border border-border shrink-0"
                }
              ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-16 w-16 rounded-xl bg-background border border-dashed border-border grid place-items-center shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Camera, { className: "h-6 w-6 text-muted-foreground" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold", children: "Photo of your child (hero)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-0.5", children: "Strongly recommended — we turn this into a Pixar-style cartoon hero (matching hair, skin tone, and age). It won't look like a copy-paste of the photo, but should feel like your child. Clear front-facing photos work best." }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex flex-wrap gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      type: "button",
                      onClick: () => heroPhotoRef.current?.click(),
                      className: "inline-flex items-center gap-1.5 rounded-full bg-primary/10 text-primary px-3 py-1.5 text-xs font-semibold hover:bg-primary/15 transition",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-3.5 w-3.5" }),
                        childPhoto ? "Change photo" : "Upload photo"
                      ]
                    }
                  ),
                  childPhoto && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => setChildPhoto(null),
                      className: "text-xs text-muted-foreground hover:text-foreground underline",
                      children: "Remove"
                    }
                  )
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                ref: heroPhotoRef,
                type: "file",
                accept: "image/*",
                className: "hidden",
                onChange: (e) => {
                  addHeroPhoto(e.target.files?.[0]);
                  if (heroPhotoRef.current) heroPhotoRef.current.value = "";
                }
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setShowOptional((v) => !v),
              className: "mt-6 w-full flex items-center justify-between rounded-xl border border-border bg-secondary/30 px-4 py-3 text-sm font-semibold hover:bg-secondary/50 transition",
              children: [
                "Customize (optional)",
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  ChevronDown,
                  {
                    className: `h-4 w-4 transition ${showOptional ? "rotate-180" : ""}`
                  }
                )
              ]
            }
          ),
          showOptional && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 space-y-6 animate-rise", children: [
            ENABLE_STORY_CAST,
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-sm font-semibold", children: "Story language" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "select",
                  {
                    value: storyLanguage,
                    onChange: (e) => setStoryLanguage(e.target.value),
                    className: "mt-2 w-full rounded-xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition",
                    children: storyLanguages.map((lang) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: lang.value, children: lang.label }, lang.value))
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Georgian and Spanish work — GPT writes the full story in that language." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-sm font-semibold", children: [
                  "Extra wishes",
                  " ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-normal text-muted-foreground", children: "(optional)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "textarea",
                  {
                    value: optionalNotes,
                    maxLength: 500,
                    rows: 3,
                    onChange: (e) => setOptionalNotes(e.target.value),
                    placeholder: "e.g. loves unicorns, afraid of loud noises, include little brother Niko",
                    className: "mt-2 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition resize-none"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Be specific — these wishes are woven into the story on multiple pages (not just the title)." })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: generate,
              disabled: !valid || status === "generatingStory" || status === "generatingPdf",
              className: "mt-8 w-full inline-flex items-center justify-center gap-2 rounded-full bg-primary text-primary-foreground py-4 font-semibold disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90 transition",
              children: status === "generatingStory" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
                "Writing your story…"
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
                "Create story"
              ] })
            }
          ),
          !valid && status !== "generatingStory" && status !== "generatingPdf" && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-3 text-xs text-amber-700 dark:text-amber-400 text-center", children: [
            "Still needed: ",
            missingRequirements.join(" · ")
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-xs text-muted-foreground text-center", children: user?.welcomeStoryRemaining ? "Your first story is a free 2-page welcome preview — then 1 full 6-page story/month." : "Free: 1 full 6-page story/month · PDF export free · Hero photo optional" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "lg:sticky lg:top-24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-3xl border border-border bg-secondary/40 p-8 min-h-[460px] overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-hero-glow opacity-60 pointer-events-none" }),
          status === "idle" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-full flex flex-col items-center justify-center text-center py-10 animate-rise", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-40 w-32 rounded-xl bg-card border border-border shadow-card grid place-items-center font-display text-muted-foreground rotate-[-4deg]", children: "Preview" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-sm text-muted-foreground max-w-xs", children: "Fill in your child's details to see a live preview of their adventure pack." }),
            ENABLE_STORY_CAST
          ] }),
          (status === "generatingStory" || status === "generatingPdf") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-full flex flex-col items-center justify-center text-center py-10 px-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-40 w-32 rounded-xl bg-card border border-border shadow-card grid place-items-center overflow-hidden", children: childPhoto ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: childPhoto,
                  alt: "",
                  className: "h-full w-full object-cover"
                }
              ) : selectedTheme && /* @__PURE__ */ jsxRuntimeExports.jsx(selectedTheme.icon, { className: "h-12 w-12 text-primary animate-float" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -top-3 -right-3 h-10 w-10 rounded-full bg-primary text-primary-foreground grid place-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-5 w-5 animate-spin" }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 w-full max-w-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2 rounded-full bg-border overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: "h-full bg-primary transition-all duration-500",
                  style: { width: `${Math.max(5, progress)}%` }
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-xs font-semibold text-primary tabular-nums", children: [
                Math.round(progress),
                "%"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-foreground font-medium min-h-[2.5rem]", children: progressMessage ?? (status === "generatingPdf" ? "Creating illustrated PDF…" : "Writing your story…") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 rounded-xl bg-card/80 border border-border p-3 text-left text-xs text-muted-foreground space-y-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-foreground", children: "You can leave this page." }),
                " ",
                "We save every book under",
                " ",
                /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/my-packs", className: "text-primary font-semibold underline", children: "My Books" }),
                ". We will email you when your illustrated story or PDF is ready."
              ] }) })
            ] })
          ] }),
          (status === "storyReady" || status === "done") && selectedTheme && packTheme && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative animate-rise", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              StoryBookReader,
              {
                pages: storyPages,
                theme: packTheme,
                title: storyTitle ?? `${name}'s ${selectedTheme.name} story`,
                childName: name,
                previewIllustrationStatus,
                isCompleted: status === "done",
                storiesRemainingThisMonth: user?.storiesRemainingThisMonth,
                bookCredits: user?.bookCredits
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-col gap-2", children: [
              status === "storyReady" && isAuthenticated && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  disabled: startingPdf,
                  onClick: () => void runPdfGeneration(),
                  className: "w-full inline-flex items-center justify-center gap-2 rounded-full bg-primary text-primary-foreground py-3 font-semibold hover:opacity-90 transition disabled:opacity-60",
                  children: [
                    startingPdf ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
                    "Export PDF — free (~30 sec)"
                  ]
                }
              ),
              status === "done" && completedPackId && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  type: "button",
                  disabled: downloading,
                  onClick: () => {
                    if (!completedPackId || !selectedTheme) return;
                    setDownloading(true);
                    const fileName = `${name}-${selectedTheme.name}-storybook.pdf`.replace(/\s+/g, "-").toLowerCase();
                    void downloadAdventurePack(completedPackId, fileName).catch(
                      () => toast.error("Could not download PDF. Open My Books and try again.")
                    ).finally(() => setDownloading(false));
                  },
                  className: "w-full inline-flex items-center justify-center gap-2 rounded-full bg-foreground text-background py-3 font-semibold hover:opacity-90 transition disabled:opacity-60",
                  children: [
                    downloading ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Gift, { className: "h-4 w-4" }),
                    "Download storybook PDF"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  onClick: reset,
                  className: "rounded-full bg-card border border-border px-4 py-3 font-semibold hover:bg-secondary transition",
                  children: "New story"
                }
              )
            ] })
          ] }),
          status === "error" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-full flex flex-col items-center justify-center text-center py-10 px-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-destructive font-medium", children: errorMessage }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: reset,
                className: "mt-4 rounded-full bg-primary text-primary-foreground px-5 py-2 text-sm font-semibold",
                children: "Try again"
              }
            )
          ] })
        ] }) })
      ] })
    ] }) })
  ] });
}
function Grandparents() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "grandparents", className: "relative py-24 md:py-32 scroll-mt-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto max-w-7xl px-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid lg:grid-cols-[1.1fr_1fr] gap-10 items-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 rounded-full bg-primary/10 text-primary px-3 py-1 text-xs font-semibold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Gift, { className: "h-3.5 w-3.5" }),
        "For grandparents"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 font-display text-4xl md:text-5xl font-bold text-balance", children: "The perfect gift for a grandchild who has everything." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-muted-foreground text-lg max-w-xl", children: "Grandparents are always looking for something meaningful. A personalized adventure book starring their grandchild beats another toy — and lasts forever." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-6 space-y-3 text-sm max-w-md", children: [
        "Personalized with their grandchild's name, age and theme",
        "Add grandma or grandpa into the story as a character",
        "15-book pack — gifts for every grandchild",
        "Print at home or ship-ready PDF — no waiting"
      ].map((f) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-0.5 grid place-items-center h-5 w-5 rounded-full bg-secondary text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "h-3 w-3" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: f })
      ] }, f)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex flex-wrap gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: "#generator",
            className: "inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-5 py-3 text-sm font-semibold hover:opacity-90 transition",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
              "Create a gift pack"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: "#pricing",
            className: "inline-flex items-center gap-2 rounded-full bg-card border border-border px-5 py-3 text-sm font-semibold hover:bg-secondary transition",
            children: [
              "See book packs",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "absolute inset-0 -z-10 rounded-[2.5rem] opacity-60 blur-3xl",
          style: { background: "var(--gradient-primary, var(--accent))" }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-3xl bg-card border border-border shadow-card p-8 rotate-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-secondary/60 p-6 -rotate-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold uppercase tracking-wide text-foreground/60", children: "A gift from Grandma" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 font-display text-2xl font-bold leading-tight", children: "Leo's Pirate Quest" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm text-muted-foreground", children: '"Captain Leo and First Mate Grandma set sail on a stormy night to find the treasure of Blue Coral Bay…"' }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 flex items-center gap-2 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-primary text-primary-foreground px-2.5 py-1 font-semibold", children: "20 pages" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-card border border-border px-2.5 py-1", children: "Premium paper" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-card border border-border px-2.5 py-1", children: "Family illustrations" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 flex items-center justify-between text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Family Keepsake" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-display text-2xl font-bold", children: "$24.99" })
        ] })
      ] })
    ] })
  ] }) }) });
}
function FinalCTA() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "relative py-24 md:py-32", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto max-w-6xl px-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative overflow-hidden rounded-[2.5rem] bg-foreground text-background p-10 md:p-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-hero-glow opacity-30 pointer-events-none" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-4xl md:text-6xl font-bold leading-tight text-balance", children: "Their next adventure is one click away." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 text-lg text-background/70", children: "Create your first personalized adventure pack free. No credit card needed." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex flex-col sm:flex-row gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: "#generator",
            className: "inline-flex items-center justify-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3.5 font-semibold hover:opacity-90 transition",
            children: [
              "Create your book",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: "#preview",
            className: "inline-flex items-center justify-center rounded-full bg-background/10 border border-background/20 text-background px-6 py-3.5 font-semibold hover:bg-background/15 transition",
            children: "View example"
          }
        )
      ] })
    ] })
  ] }) }) });
}
function Landing() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background text-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Hero, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(HowItWorks, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Generator, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Themes, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Preview, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Benefits, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Grandparents, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Pricing, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FAQ, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FinalCTA, {})
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
export {
  Landing as component
};
