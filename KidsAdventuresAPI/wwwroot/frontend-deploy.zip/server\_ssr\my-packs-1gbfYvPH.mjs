import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { N as Nav, F as Footer, A as AuthDialog, c as cn, f as formatCreditsBadgeLabel } from "./Footer-oFmOtiDq.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as useAuth } from "./router-B8qRGRuM.mjs";
import { l as listAdventurePacks, a as listChildren, i as isPackGenerating, g as getAdventurePack, c as computePackProgressPercent, S as StoryBookReader, b as isPackIllustrating, d as isPackReadable, e as generatePackPdf, p as pollAdventurePack, f as downloadAdventurePack } from "./StoryBookReader-ntxFssvk.mjs";
import { L as Library, P as Plus, R as RefreshCw, a as Package, b as LoaderCircle, S as Sparkles, D as Download, B as BookOpen, C as ChevronLeft, c as ChevronRight } from "../_libs/lucide-react.mjs";
import { f as format } from "../_libs/date-fns.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "./BrandLogo-T23ohXas.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/embla-carousel-react.mjs";
import "../_libs/embla-carousel-reactive-utils.mjs";
import "../_libs/embla-carousel.mjs";
function CreditsBadge({
  credits,
  storiesRemainingThisMonth = 0,
  variant = "compact",
  className,
  linkToPricing = false
}) {
  const label = formatCreditsBadgeLabel({
    bookCredits: credits,
    storiesRemainingThisMonth
  });
  const inner = /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "span",
    {
      className: cn(
        "inline-flex items-center gap-1.5 font-bold",
        variant === "compact" ? "rounded-full border border-amber-300 bg-amber-400 px-2.5 py-1 text-[11px] text-amber-950 shadow-sm" : "rounded-2xl border border-amber-300 bg-amber-400 px-4 py-2.5 text-sm text-amber-950 shadow-md",
        className
      ),
      title: "1 free full story per month, plus 1 extra story per purchased credit",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Sparkles,
          {
            className: cn("shrink-0 text-amber-900", variant === "compact" ? "h-3.5 w-3.5" : "h-5 w-5")
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: label })
      ]
    }
  );
  if (linkToPricing && credits === 0 && storiesRemainingThisMonth === 0) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", hash: "pricing", className: "hover:opacity-90 transition", children: inner });
  }
  return inner;
}
const BOOKS_PER_PAGE = 6;
const statusStyles = {
  Pending: { label: "Queued", className: "bg-amber-100 text-amber-900" },
  Generating: { label: "Writing story…", className: "bg-sky-100 text-sky-900" },
  GeneratingStory: { label: "Writing story…", className: "bg-sky-100 text-sky-900" },
  StoryReady: { label: "Story ready", className: "bg-violet-100 text-violet-900" },
  GeneratingPdf: { label: "Creating PDF…", className: "bg-sky-100 text-sky-900" },
  Completed: { label: "PDF ready", className: "bg-emerald-100 text-emerald-900" },
  Failed: { label: "Failed", className: "bg-red-100 text-red-900" }
};
function slideshowIllustrationsReady(pack) {
  return isPackReadable(pack);
}
function needsPreviewPoll(pack) {
  return isPackIllustrating(pack);
}
function packStatusDisplay(pack) {
  if (isPackIllustrating(pack)) {
    return { label: "Creating illustrations…", className: "bg-sky-100 text-sky-900" };
  }
  return statusStyles[pack.status];
}
function MyPacks() {
  const { isAuthenticated, isLoading, canCreatePdf, refreshAccountBalance, setBookCredits, user } = useAuth();
  const [authOpen, setAuthOpen] = reactExports.useState(false);
  const [packs, setPacks] = reactExports.useState([]);
  const [childNames, setChildNames] = reactExports.useState({});
  const [loading, setLoading] = reactExports.useState(false);
  const [downloadingId, setDownloadingId] = reactExports.useState(null);
  const [pdfStartingId, setPdfStartingId] = reactExports.useState(null);
  const [expandedId, setExpandedId] = reactExports.useState(null);
  const [readerLoadingId, setReaderLoadingId] = reactExports.useState(null);
  const [error, setError] = reactExports.useState(null);
  const [page, setPage] = reactExports.useState(1);
  const updatePack = reactExports.useCallback((updated) => {
    setPacks((prev) => prev.map((p) => p.id === updated.id ? { ...p, ...updated } : p));
  }, []);
  const load = reactExports.useCallback(async (options) => {
    if (!isAuthenticated) return;
    const refreshInProgressOnly = options?.refreshInProgressOnly ?? false;
    if (!refreshInProgressOnly) {
      setLoading(true);
    }
    setError(null);
    try {
      const packRows = await listAdventurePacks();
      const children = refreshInProgressOnly ? null : await listChildren();
      const sorted = [...packRows].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      const detailTargets = sorted.filter(
        (p) => isPackGenerating(p) || needsPreviewPoll(p)
      );
      const details = await Promise.all(
        detailTargets.map((p) => getAdventurePack(p.id).catch(() => p))
      );
      const detailMap = Object.fromEntries(details.map((d) => [d.id, d]));
      setPacks((prev) => {
        const prevMap = Object.fromEntries(prev.map((p) => [p.id, p]));
        return sorted.map((p) => detailMap[p.id] ?? prevMap[p.id] ?? p);
      });
      if (children) {
        setChildNames(Object.fromEntries(children.map((c) => [c.id, c.name])));
      }
    } catch {
      setError("Could not load your books. Try again.");
    } finally {
      if (!refreshInProgressOnly) {
        setLoading(false);
      }
    }
  }, [isAuthenticated]);
  reactExports.useEffect(() => {
    void load();
  }, [load]);
  reactExports.useEffect(() => {
    if (isAuthenticated) {
      void refreshAccountBalance();
    }
  }, [isAuthenticated, refreshAccountBalance]);
  const totalPages = Math.max(1, Math.ceil(packs.length / BOOKS_PER_PAGE));
  const paginatedPacks = reactExports.useMemo(() => {
    const start = (page - 1) * BOOKS_PER_PAGE;
    return packs.slice(start, start + BOOKS_PER_PAGE);
  }, [packs, page]);
  reactExports.useEffect(() => {
    if (page > totalPages) {
      setPage(totalPages);
    }
  }, [page, totalPages]);
  const hasInProgress = reactExports.useMemo(
    () => packs.some((p) => isPackGenerating(p)),
    [packs]
  );
  reactExports.useEffect(() => {
    if (!isAuthenticated || !hasInProgress) return;
    const timer = window.setInterval(() => void load({ refreshInProgressOnly: true }), 5e3);
    return () => window.clearInterval(timer);
  }, [isAuthenticated, hasInProgress, load]);
  reactExports.useEffect(() => {
    if (!expandedId) return;
    const pack = packs.find((p) => p.id === expandedId);
    if (!pack || !needsPreviewPoll(pack)) return;
    const timer = window.setInterval(() => {
      void getAdventurePack(expandedId).then(updatePack);
    }, 3e3);
    return () => window.clearInterval(timer);
  }, [expandedId, packs, updatePack]);
  const openReader = async (pack) => {
    if (!slideshowIllustrationsReady(pack)) {
      toast.message("Your story is still being illustrated. Check back in a minute.");
      return;
    }
    if (expandedId === pack.id) {
      setExpandedId(null);
      return;
    }
    setExpandedId(pack.id);
    setReaderLoadingId(pack.id);
    try {
      const fresh = await getAdventurePack(pack.id);
      updatePack(fresh);
    } catch {
      toast.error("Could not load story preview. Try Refresh.");
    } finally {
      setReaderLoadingId(null);
    }
  };
  const openDownload = async (pack) => {
    if (pack.status !== "Completed" || downloadingId) return;
    const childName = childNames[pack.childId] ?? pack.childName ?? "storybook";
    const fileName = `${childName}-${pack.theme}-storybook.pdf`.replace(/\s+/g, "-").toLowerCase();
    setDownloadingId(pack.id);
    try {
      await downloadAdventurePack(pack.id, fileName);
    } catch {
      toast.error("Could not download PDF. Try creating the illustrated PDF again.");
    } finally {
      setDownloadingId(null);
    }
  };
  const startPdf = async (pack) => {
    if (pack.status !== "StoryReady" || pdfStartingId) return;
    if (!slideshowIllustrationsReady(pack)) {
      toast.message("Wait until every page is illustrated, then export PDF.");
      return;
    }
    setPdfStartingId(pack.id);
    try {
      const queued = await generatePackPdf(pack.id);
      if (typeof queued.bookCredits === "number") {
        setBookCredits(queued.bookCredits);
      } else {
        await refreshAccountBalance();
      }
      toast.success("Building your PDF from slideshow illustrations — about 30 seconds.");
      await pollAdventurePack(
        pack.id,
        updatePack,
        {
          untilStatus: "Completed",
          maxAttempts: 30
        }
      );
      toast.success("Your storybook PDF is ready!");
      await refreshAccountBalance();
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "PDF creation failed.");
      await load();
    } finally {
      setPdfStartingId(null);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "py-12 md:py-16 bg-secondary/30 border-y border-border/60 min-h-[60vh]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-5xl px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-6 mb-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid place-items-center h-14 w-14 shrink-0 rounded-2xl bg-primary/10 ring-1 ring-primary/20 shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Library, { className: "h-7 w-7 text-primary" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary uppercase tracking-wide", children: "Your library" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-3xl font-bold tracking-tight mt-0.5", children: "My Books" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-muted-foreground mt-2 max-w-xl text-sm", children: [
                "Read the slideshow for free. Each ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-foreground", children: "PDF export" }),
                " uses one book credit."
              ] })
            ] })
          ] }),
          isAuthenticated && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 sm:justify-end", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Link,
              {
                to: "/",
                hash: "generator",
                className: "inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-4 py-2 text-sm font-semibold hover:opacity-90 transition",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
                  "New story"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => void load(),
                disabled: loading,
                className: "inline-flex items-center justify-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold hover:bg-background transition disabled:opacity-50",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `h-4 w-4 ${loading ? "animate-spin" : ""}` }),
                  "Refresh"
                ]
              }
            )
          ] })
        ] }),
        isAuthenticated && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 px-4 py-4 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-semibold uppercase tracking-wide text-amber-900/80", children: "Your story credits" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-amber-950/80 mt-0.5", children: user && user.bookCredits > 0 ? `${user.bookCredits} purchased credit${user.bookCredits === 1 ? "" : "s"} plus 1 free story every month. PDF export is always free.` : "PDF export is free for every story. Buy credits for extra stories beyond your monthly free one." })
          ] }),
          isLoading || !user ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-36 rounded-full bg-amber-200/60 animate-pulse" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            CreditsBadge,
            {
              credits: user.bookCredits,
              storiesRemainingThisMonth: user.storiesRemainingThisMonth,
              variant: "prominent",
              linkToPricing: user.bookCredits === 0 && user.storiesRemainingThisMonth === 0
            }
          )
        ] }),
        isAuthenticated && user && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card px-4 py-3 shadow-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground", children: "Stories saved" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-display text-2xl font-bold mt-1", children: packs.length })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-card px-4 py-3 shadow-sm flex flex-col justify-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: user.storiesRemainingThisMonth > 0 ? `${user.storiesRemainingThisMonth} of ${user.storiesAllowedThisMonth} stories left this month — each is a full 6-page illustrated book.` : "Monthly story limit reached. Buy book credits for more adventures — PDF export stays free." }),
            user.storiesRemainingThisMonth === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
              Link,
              {
                to: "/",
                hash: "pricing",
                className: "mt-2 inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline",
                children: "View book packs"
              }
            )
          ] })
        ] })
      ] }),
      !isAuthenticated ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-border bg-card p-10 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { className: "h-10 w-10 mx-auto text-muted-foreground mb-4" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mb-4", children: "Sign in to see books you have created." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            onClick: () => setAuthOpen(true),
            className: "inline-flex items-center rounded-full bg-primary text-primary-foreground px-6 py-2.5 text-sm font-semibold hover:opacity-90 transition",
            children: "Sign in"
          }
        )
      ] }) : loading && packs.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 py-16 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-5 w-5 animate-spin" }),
        "Loading your books…"
      ] }) : error ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-3xl border border-destructive/30 bg-destructive/5 p-6 text-center text-destructive", children: error }) : packs.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-dashed border-border bg-card p-10 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "No books yet. Create your first story below." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: "/",
            hash: "generator",
            className: "inline-flex mt-4 items-center rounded-full bg-primary text-primary-foreground px-6 py-2.5 text-sm font-semibold hover:opacity-90 transition",
            children: "Create a book"
          }
        )
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "grid gap-4", children: paginatedPacks.map((pack) => {
          const status = packStatusDisplay(pack);
          const childName = childNames[pack.childId] ?? pack.childName ?? "Child";
          const expanded = expandedId === pack.id;
          const generating = isPackGenerating(pack);
          const progressPct = computePackProgressPercent(pack);
          const readable = slideshowIllustrationsReady(pack);
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "li",
            {
              className: "rounded-2xl border border-border bg-card p-5 flex flex-col gap-4",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center gap-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 mb-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-xs font-bold px-2.5 py-0.5 rounded-full ${status.className}`, children: status.label }),
                      generating && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-medium text-sky-700 flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-3 w-3 animate-spin" }),
                        "In progress"
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: format(new Date(pack.createdAt), "MMM d, yyyy · h:mm a") })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-display text-lg font-semibold truncate", children: pack.title ?? `${childName}'s ${pack.theme} story` }),
                    generating && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 max-w-md", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2 rounded-full bg-border overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "div",
                        {
                          className: "h-full bg-primary transition-all duration-500",
                          style: { width: `${Math.max(5, progressPct)}%` }
                        }
                      ) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1.5 text-xs text-muted-foreground tabular-nums", children: [
                        progressPct,
                        "% · ",
                        pack.progressMessage ?? "Working on your storybook…"
                      ] })
                    ] }),
                    pack.status === "Failed" && pack.errorMessage && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-destructive/90 mt-1 line-clamp-3", children: pack.errorMessage })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 shrink-0", children: [
                    readable && pack.status === "StoryReady" && isAuthenticated && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => void startPdf(pack),
                        disabled: pdfStartingId === pack.id,
                        className: "inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-4 py-2.5 text-sm font-semibold hover:opacity-90 transition disabled:opacity-60",
                        children: [
                          pdfStartingId === pack.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
                          "Export PDF (free)"
                        ]
                      }
                    ),
                    pack.status === "Completed" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => void openDownload(pack),
                        disabled: downloadingId === pack.id,
                        className: "inline-flex items-center gap-2 rounded-full bg-foreground text-background px-4 py-2.5 text-sm font-semibold hover:opacity-90 transition disabled:opacity-60",
                        children: [
                          downloadingId === pack.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
                          "Download storybook PDF"
                        ]
                      }
                    ),
                    pack.status === "Failed" && /* @__PURE__ */ jsxRuntimeExports.jsx(
                      Link,
                      {
                        to: "/",
                        hash: "generator",
                        className: "inline-flex items-center rounded-full border border-border px-4 py-2.5 text-sm font-semibold hover:bg-secondary transition",
                        children: "Try again"
                      }
                    ),
                    readable && (pack.status === "StoryReady" || pack.status === "Completed") && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        type: "button",
                        onClick: () => void openReader(pack),
                        className: "inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-2.5 text-sm font-semibold hover:bg-secondary transition",
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-4 w-4" }),
                          expanded ? "Hide story" : "Read story"
                        ]
                      }
                    )
                  ] })
                ] }),
                expanded && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-rise pt-2", children: readerLoadingId === pack.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 py-16 text-muted-foreground", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-6 w-6 animate-spin" }),
                  "Opening your storybook…"
                ] }) : pack.storyPages && pack.storyPages.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  StoryBookReader,
                  {
                    pages: pack.storyPages,
                    theme: pack.theme,
                    title: pack.title ?? `${childName}'s ${pack.theme} story`,
                    childName,
                    previewIllustrationStatus: pack.previewIllustrationStatus,
                    isCompleted: pack.status === "Completed",
                    storiesRemainingThisMonth: user?.storiesRemainingThisMonth,
                    bookCredits: user?.bookCredits
                  }
                ) : null })
              ]
            },
            pack.id
          );
        }) }),
        totalPages > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "nav",
          {
            className: "mt-6 flex flex-col sm:flex-row items-center justify-between gap-3",
            "aria-label": "Books pagination",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
                "Showing ",
                (page - 1) * BOOKS_PER_PAGE + 1,
                "–",
                Math.min(page * BOOKS_PER_PAGE, packs.length),
                " of ",
                packs.length,
                " books"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setPage((p) => Math.max(1, p - 1)),
                    disabled: page === 1,
                    className: "inline-flex items-center gap-1 rounded-full border border-border bg-card px-3 py-1.5 text-sm font-semibold hover:bg-secondary transition disabled:opacity-40",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-4 w-4" }),
                      "Previous"
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm font-medium px-2", children: [
                  "Page ",
                  page,
                  " of ",
                  totalPages
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
                    disabled: page === totalPages,
                    className: "inline-flex items-center gap-1 rounded-full border border-border bg-card px-3 py-1.5 text-sm font-semibold hover:bg-secondary transition disabled:opacity-40",
                    children: [
                      "Next",
                      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4" })
                    ]
                  }
                )
              ] })
            ]
          }
        )
      ] }),
      hasInProgress && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground text-center mt-4", children: "Stories and preview pictures update automatically every few seconds." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AuthDialog, { open: authOpen, onOpenChange: setAuthOpen, defaultMode: "login" })
  ] });
}
function MyPacksPage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background text-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "pt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto max-w-5xl px-6 pb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "text-sm text-muted-foreground hover:text-foreground transition-colors", children: "← Back to home" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(MyPacks, {})
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
export {
  MyPacksPage as component
};
