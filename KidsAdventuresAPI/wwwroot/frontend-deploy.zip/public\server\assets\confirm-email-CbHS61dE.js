import { jsxs, jsx } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { R as Route, c as confirmEmail } from "./router-HBU99EUm.js";
import { B as BrandLogo } from "./BrandLogo-T23ohXas.js";
import "@tanstack/react-query";
import "sonner";
import "lucide-react";
function ConfirmEmailPage() {
  const {
    success,
    token
  } = Route.useSearch();
  const navigate = useNavigate();
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState(null);
  const handleConfirm = async () => {
    if (!token) return;
    setConfirming(true);
    setError(null);
    try {
      const result = await confirmEmail(token);
      if (result.success) {
        navigate({
          to: "/confirm-email",
          search: {
            success: true
          },
          replace: true
        });
      } else {
        setError(result.message);
      }
    } catch {
      setError("Could not confirm your email. Check that the API is running and try again.");
    } finally {
      setConfirming(false);
    }
  };
  const showConfirmButton = Boolean(token) && !success;
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-background text-foreground flex flex-col items-center justify-center px-6", children: [
    /* @__PURE__ */ jsx(BrandLogo, { className: "mb-10" }),
    /* @__PURE__ */ jsxs("div", { className: "max-w-md w-full rounded-3xl border border-border bg-card p-8 text-center shadow-card", children: [
      /* @__PURE__ */ jsx("h1", { className: "font-display text-2xl font-bold", children: success ? "Email confirmed!" : showConfirmButton ? "Confirm your email" : "Confirmation link invalid" }),
      /* @__PURE__ */ jsx("p", { className: "mt-3 text-muted-foreground text-sm", children: success ? "Your account is active. Sign in to start creating personalized storybooks." : showConfirmButton ? "Click the button below to activate your LittleHero Books account." : "This link may have expired. If you already clicked it once, try signing in — your email may already be confirmed." }),
      error ? /* @__PURE__ */ jsx("p", { className: "mt-3 text-destructive text-sm", children: error }) : null,
      showConfirmButton ? /* @__PURE__ */ jsx("button", { type: "button", onClick: handleConfirm, disabled: confirming, className: "inline-flex mt-6 items-center rounded-full bg-primary text-primary-foreground px-6 py-2.5 text-sm font-semibold hover:opacity-90 transition disabled:opacity-60", children: confirming ? "Confirming…" : "Confirm my email" }) : /* @__PURE__ */ jsx(Link, { to: "/", className: "inline-flex mt-6 items-center rounded-full bg-primary text-primary-foreground px-6 py-2.5 text-sm font-semibold hover:opacity-90 transition", children: success ? "Sign in" : "Back to home" })
    ] })
  ] });
}
export {
  ConfirmEmailPage as component
};
