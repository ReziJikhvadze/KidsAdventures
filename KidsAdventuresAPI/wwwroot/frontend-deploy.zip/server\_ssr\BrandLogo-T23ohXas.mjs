import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { B as BookOpen } from "../_libs/lucide-react.mjs";
function BrandLogo({ className = "", asLink = true }) {
  const content = /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-flex items-center justify-center h-8 w-8 rounded-xl bg-primary text-primary-foreground shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-4 w-4" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-display text-lg font-bold tracking-tight", children: "LittleHero Books" })
  ] });
  if (!asLink) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex items-center gap-2 ${className}`, children: content });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: `flex items-center gap-2 ${className}`, children: content });
}
export {
  BrandLogo as B
};
